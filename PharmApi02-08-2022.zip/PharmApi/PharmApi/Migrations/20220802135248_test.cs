﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace PharmApi.Migrations
{
    public partial class test : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "ACCLeadger",
                columns: table => new
                {
                    id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    transno = table.Column<int>(type: "int", nullable: false),
                    ACCcountCode = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    AccountName = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    ACCName = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    ACCAName = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    TransDate = table.Column<DateTime>(type: "datetime2", nullable: true),
                    TransType = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    ReceiptNO = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Currancy = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Rate = table.Column<decimal>(type: "decimal(18,2)", nullable: true),
                    Amount = table.Column<decimal>(type: "decimal(18,2)", nullable: true),
                    Depit = table.Column<decimal>(type: "decimal(18,2)", nullable: true),
                    Credit = table.Column<decimal>(type: "decimal(18,2)", nullable: true),
                    Depit1 = table.Column<decimal>(type: "decimal(18,2)", nullable: true),
                    Credit1 = table.Column<decimal>(type: "decimal(18,2)", nullable: true),
                    Notes = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    DueDate = table.Column<DateTime>(type: "datetime2", nullable: true),
                    REF = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ACCLeadger", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "ACCOUNTINSHS",
                columns: table => new
                {
                    ID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    INTH_NAME = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    INTH_USE = table.Column<int>(type: "int", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ACCOUNTINSHS", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "AccountsChart",
                columns: table => new
                {
                    ACCCode = table.Column<string>(type: "nvarchar(450)", nullable: false),
                    PARENTCode = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    ACCName = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    ACCAName = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Currency = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    ACCKind = table.Column<bool>(type: "bit", nullable: true),
                    Receipt = table.Column<bool>(type: "bit", nullable: true),
                    Payment = table.Column<bool>(type: "bit", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_AccountsChart", x => x.ACCCode);
                });

            migrationBuilder.CreateTable(
                name: "accountshortcutstor",
                columns: table => new
                {
                    id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    pharm_code = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    pharmname = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    StoreId = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Stor_Name = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_accountshortcutstor", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "ActionsCode",
                columns: table => new
                {
                    id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    ActionName = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    AccCode = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ActionsCode", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "AspNetRoles",
                columns: table => new
                {
                    Id = table.Column<string>(type: "nvarchar(450)", nullable: false),
                    Name = table.Column<string>(type: "nvarchar(256)", maxLength: 256, nullable: true),
                    NormalizedName = table.Column<string>(type: "nvarchar(256)", maxLength: 256, nullable: true),
                    ConcurrencyStamp = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_AspNetRoles", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "AspNetUsers",
                columns: table => new
                {
                    Id = table.Column<string>(type: "nvarchar(450)", nullable: false),
                    UserName = table.Column<string>(type: "nvarchar(256)", maxLength: 256, nullable: true),
                    NormalizedUserName = table.Column<string>(type: "nvarchar(256)", maxLength: 256, nullable: true),
                    Email = table.Column<string>(type: "nvarchar(256)", maxLength: 256, nullable: true),
                    NormalizedEmail = table.Column<string>(type: "nvarchar(256)", maxLength: 256, nullable: true),
                    EmailConfirmed = table.Column<bool>(type: "bit", nullable: false),
                    PasswordHash = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    SecurityStamp = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    ConcurrencyStamp = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    PhoneNumber = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    PhoneNumberConfirmed = table.Column<bool>(type: "bit", nullable: false),
                    TwoFactorEnabled = table.Column<bool>(type: "bit", nullable: false),
                    LockoutEnd = table.Column<DateTimeOffset>(type: "datetimeoffset", nullable: true),
                    LockoutEnabled = table.Column<bool>(type: "bit", nullable: false),
                    AccessFailedCount = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_AspNetUsers", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Cheque",
                columns: table => new
                {
                    id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    ReceiptNO = table.Column<int>(type: "int", nullable: false),
                    ChequeNO = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    BankName = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    DueDate = table.Column<DateTime>(type: "datetime2", nullable: true),
                    Currancy = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Rate = table.Column<double>(type: "float", nullable: true),
                    Value = table.Column<double>(type: "float", nullable: true),
                    AddedUser = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    DateUpdate = table.Column<DateTime>(type: "datetime2", nullable: true),
                    Back = table.Column<bool>(type: "bit", nullable: true),
                    returnBy = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    ReturnDate = table.Column<DateTime>(type: "datetime2", nullable: true),
                    InTreasury = table.Column<bool>(type: "bit", nullable: true),
                    TreasuryDate = table.Column<DateTime>(type: "datetime2", nullable: true),
                    INBank = table.Column<bool>(type: "bit", nullable: true),
                    BankCode = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    BankDate = table.Column<DateTime>(type: "datetime2", nullable: true),
                    Collected = table.Column<bool>(type: "bit", nullable: true),
                    CollectedDate = table.Column<DateTime>(type: "datetime2", nullable: true),
                    AccountNO = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Refuesd = table.Column<bool>(type: "bit", nullable: true),
                    RefuesdDate = table.Column<DateTime>(type: "datetime2", nullable: true),
                    Collector = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    BankCharge = table.Column<double>(type: "float", nullable: true),
                    Ordering = table.Column<byte>(type: "tinyint", nullable: false),
                    Type = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Active = table.Column<bool>(type: "bit", nullable: true),
                    ActiveDate = table.Column<DateTime>(type: "datetime2", nullable: true),
                    PrintName = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Cheque", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "ChequeTemplate",
                columns: table => new
                {
                    id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    BankCode = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Template = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    CreditCode = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ChequeTemplate", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "CollectedVoucher",
                columns: table => new
                {
                    ReceiptNO = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    RecRef = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    ReceiptDate = table.Column<DateTime>(type: "datetime2", nullable: true),
                    SaveCode = table.Column<int>(type: "int", nullable: true),
                    Amount = table.Column<double>(type: "float", nullable: true),
                    Currency = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Rate = table.Column<double>(type: "float", nullable: true),
                    Type = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    VSource = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    CollectedCode = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    CollectedName = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Description = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    AddedUser = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    AddedDate = table.Column<DateTime>(type: "datetime2", nullable: true),
                    Approved = table.Column<bool>(type: "bit", nullable: true),
                    ChequeNO = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    BankCode = table.Column<int>(type: "int", nullable: true),
                    DueDate = table.Column<DateTime>(type: "datetime2", nullable: true),
                    AccountNO = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    TotalString = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Received = table.Column<bool>(type: "bit", nullable: true),
                    CostCenter = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_CollectedVoucher", x => x.ReceiptNO);
                });

            migrationBuilder.CreateTable(
                name: "Company",
                columns: table => new
                {
                    com_id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    com_code = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    com_name_ar = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    com_name_en = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    com_tel = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    com_address = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    com_usr_code = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    com_active = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    sec_insert_uid = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    sec_insert_date = table.Column<DateTime>(type: "datetime2", nullable: true),
                    sec_update_uid = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    sec_update_date = table.Column<DateTime>(type: "datetime2", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Company", x => x.com_id);
                });

            migrationBuilder.CreateTable(
                name: "Coupon",
                columns: table => new
                {
                    cou_Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    cust_id = table.Column<decimal>(type: "decimal(18,2)", nullable: false),
                    bill_id = table.Column<decimal>(type: "decimal(18,2)", nullable: false),
                    total_cach = table.Column<decimal>(type: "decimal(18,2)", nullable: true),
                    actual_total_cash = table.Column<decimal>(type: "decimal(18,2)", nullable: true),
                    total_bill_cash = table.Column<decimal>(type: "decimal(18,2)", nullable: true),
                    total_bill_cash_exch = table.Column<decimal>(type: "decimal(18,2)", nullable: true),
                    sec_insert_date = table.Column<DateTime>(type: "datetime2", nullable: true),
                    sec_insert_uid = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    sec_update_date = table.Column<DateTime>(type: "datetime2", nullable: true),
                    sec_update_uid = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    recipient_name = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    status = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    coup_form = table.Column<int>(type: "int", nullable: true),
                    id = table.Column<int>(type: "int", nullable: false),
                    mov_id = table.Column<int>(type: "int", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Coupon", x => x.cou_Id);
                });

            migrationBuilder.CreateTable(
                name: "Currency",
                columns: table => new
                {
                    Code = table.Column<string>(type: "nvarchar(450)", nullable: false),
                    Name = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Rate = table.Column<double>(type: "float", nullable: true),
                    AddUser = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    DateUpdate = table.Column<DateTime>(type: "datetime2", nullable: true),
                    Sort = table.Column<int>(type: "int", nullable: true),
                    EGPRate = table.Column<double>(type: "float", nullable: true),
                    FSort = table.Column<int>(type: "int", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Currency", x => x.Code);
                });

            migrationBuilder.CreateTable(
                name: "CurrencyHistory",
                columns: table => new
                {
                    ID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Code = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Name = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Rate = table.Column<double>(type: "float", nullable: true),
                    AddUser = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    DateUpdate = table.Column<DateTime>(type: "datetime2", nullable: true),
                    Sort = table.Column<int>(type: "int", nullable: true),
                    EGPRate = table.Column<double>(type: "float", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_CurrencyHistory", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "Customer",
                columns: table => new
                {
                    id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    cust_id = table.Column<decimal>(type: "decimal(18,2)", nullable: false),
                    cust_code = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    cust_name_ar = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    cust_name_en = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    cust_birth_date = table.Column<DateTime>(type: "datetime2", nullable: true),
                    cust_gender = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    cust_job = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    cust_mobile = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    cust_tel = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    cust_address = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    cust_type = table.Column<decimal>(type: "decimal(18,2)", nullable: true),
                    cust_parent = table.Column<decimal>(type: "decimal(18,2)", nullable: true),
                    cust_active = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    cust_active_date = table.Column<DateTime>(type: "datetime2", nullable: true),
                    cust_stop_date = table.Column<DateTime>(type: "datetime2", nullable: true),
                    cust_max_credit = table.Column<decimal>(type: "decimal(18,2)", nullable: true),
                    cust_current_credit = table.Column<decimal>(type: "decimal(18,2)", nullable: true),
                    cust_pay_perc = table.Column<double>(type: "float", nullable: true),
                    cust_discount_level = table.Column<decimal>(type: "decimal(18,2)", nullable: true),
                    cust_discount_value = table.Column<decimal>(type: "decimal(18,2)", nullable: true),
                    cust_discount_perc = table.Column<double>(type: "float", nullable: true),
                    cust_sell_cost = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    cust_profit_perc = table.Column<double>(type: "float", nullable: true),
                    cust_parent_items = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    cust_parent_groups = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    cust_parent_rules = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    cust_car_number = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    cust_payment = table.Column<int>(type: "int", nullable: true),
                    cust_ph_owner_name = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    cust_contract_id = table.Column<decimal>(type: "decimal(18,2)", nullable: true),
                    cust_p_branch_id = table.Column<decimal>(type: "decimal(18,2)", nullable: true),
                    cust_med_insurance = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    cust_extra_disc = table.Column<decimal>(type: "decimal(18,2)", nullable: true),
                    sec_insert_uid = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    sec_insert_date = table.Column<DateTime>(type: "datetime2", nullable: true),
                    sec_update_uid = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    sec_update_date = table.Column<DateTime>(type: "datetime2", nullable: true),
                    cust_rec_name = table.Column<int>(type: "int", nullable: true),
                    c_local_items_disc = table.Column<decimal>(type: "decimal(18,2)", nullable: true),
                    c_imported_items_disc = table.Column<decimal>(type: "decimal(18,2)", nullable: true),
                    c_local_made_items_disc = table.Column<decimal>(type: "decimal(18,2)", nullable: true),
                    c_special_import_items_disc = table.Column<decimal>(type: "decimal(18,2)", nullable: true),
                    c_investment_items_disc = table.Column<decimal>(type: "decimal(18,2)", nullable: true),
                    c_other_items_disc = table.Column<decimal>(type: "decimal(18,2)", nullable: true),
                    cust_start_credit = table.Column<decimal>(type: "decimal(18,2)", nullable: true),
                    cust_start_debit = table.Column<decimal>(type: "decimal(18,2)", nullable: true),
                    pont2mony = table.Column<decimal>(type: "decimal(18,2)", nullable: true),
                    cust_curr_points = table.Column<decimal>(type: "decimal(18,2)", nullable: true),
                    cust_def_sell_store = table.Column<decimal>(type: "decimal(18,2)", nullable: true),
                    cust_notes = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    cust_region_id = table.Column<int>(type: "int", nullable: true),
                    cust_prevent_credit = table.Column<int>(type: "int", nullable: true),
                    pharm_code = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    cust_contractcompany = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    cust_contractcompanydiscount = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Customer", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "Customer_branches",
                columns: table => new
                {
                    id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    cb_id = table.Column<decimal>(type: "decimal(18,2)", nullable: false),
                    cb_code = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    cb_name_ar = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    cb_name_en = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    cb_manager = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    cb_address = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    cb_tel = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    cb_cust_id = table.Column<decimal>(type: "decimal(18,2)", nullable: true),
                    sec_insert_uid = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    sec_insert_date = table.Column<DateTime>(type: "datetime2", nullable: true),
                    sec_update_uid = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    sec_update_date = table.Column<DateTime>(type: "datetime2", nullable: true),
                    pharm_id = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Customer_branches", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "Customer_Contracts",
                columns: table => new
                {
                    id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    cc_id = table.Column<decimal>(type: "decimal(18,2)", nullable: false),
                    cc_cust_id = table.Column<decimal>(type: "decimal(18,2)", nullable: false),
                    cc_number = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    cc_name = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    cc_max_bill_value = table.Column<decimal>(type: "decimal(18,2)", nullable: false),
                    cc_dis_perc = table.Column<decimal>(type: "decimal(18,2)", nullable: false),
                    cc_dis_per_for_cust = table.Column<decimal>(type: "decimal(18,2)", nullable: false),
                    cc_pay_perc = table.Column<decimal>(type: "decimal(18,2)", nullable: false),
                    cc_pay_perc_rule = table.Column<int>(type: "int", nullable: false),
                    cc_extra_discount = table.Column<decimal>(type: "decimal(18,2)", nullable: false),
                    cc_active = table.Column<int>(type: "int", nullable: false),
                    cc_local_items_disc = table.Column<decimal>(type: "decimal(18,2)", nullable: false),
                    cc_imported_items_disc = table.Column<decimal>(type: "decimal(18,2)", nullable: false),
                    cc_local_made_items_disc = table.Column<decimal>(type: "decimal(18,2)", nullable: false),
                    cc_special_import_items_disc = table.Column<decimal>(type: "decimal(18,2)", nullable: false),
                    cc_investment_items_disc = table.Column<decimal>(type: "decimal(18,2)", nullable: false),
                    cc_other_items_disc = table.Column<decimal>(type: "decimal(18,2)", nullable: false),
                    cc_g_p_doctor_max = table.Column<decimal>(type: "decimal(18,2)", nullable: false),
                    cc_disc_rule = table.Column<int>(type: "int", nullable: false),
                    sec_insert_uid = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    sec_insert_date = table.Column<DateTime>(type: "datetime2", nullable: true),
                    sec_update_uid = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    sec_update_date = table.Column<DateTime>(type: "datetime2", nullable: true),
                    cc_pay_value = table.Column<decimal>(type: "decimal(18,2)", nullable: false),
                    pharm_id = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Customer_Contracts", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "customer_credit_chng",
                columns: table => new
                {
                    id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    cc_id = table.Column<decimal>(type: "decimal(18,2)", nullable: false),
                    cc_cust_id = table.Column<decimal>(type: "decimal(18,2)", nullable: true),
                    cc_old_credit = table.Column<decimal>(type: "decimal(18,2)", nullable: true),
                    cc_new_credit = table.Column<decimal>(type: "decimal(18,2)", nullable: true),
                    cc_prog_name = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    cc_pc_name = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    cc_operation = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    cc_insert_date = table.Column<DateTime>(type: "datetime2", nullable: true),
                    pharm_id = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_customer_credit_chng", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "Customer_Delivery",
                columns: table => new
                {
                    id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    cd_cust_id = table.Column<decimal>(type: "decimal(18,2)", nullable: false),
                    cd_id = table.Column<decimal>(type: "decimal(18,2)", nullable: false),
                    cd_contact_person = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    cd_tel = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    cd_address = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    cd_notes = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    sec_insert_uid = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    sec_insert_date = table.Column<DateTime>(type: "datetime2", nullable: true),
                    sec_update_uid = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    sec_update_date = table.Column<DateTime>(type: "datetime2", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Customer_Delivery", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "Customer_Groups",
                columns: table => new
                {
                    id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    cg_cust_id = table.Column<decimal>(type: "decimal(18,2)", nullable: false),
                    cg_grp_id = table.Column<decimal>(type: "decimal(18,2)", nullable: false),
                    cg_path = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    sec_insert_uid = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    sec_insert_date = table.Column<DateTime>(type: "datetime2", nullable: true),
                    sec_update_uid = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    sec_update_date = table.Column<DateTime>(type: "datetime2", nullable: true),
                    pharm_id = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Customer_Groups", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "Customer_Items",
                columns: table => new
                {
                    id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    ci_cust_id = table.Column<decimal>(type: "decimal(18,2)", nullable: false),
                    ci_itm_id = table.Column<decimal>(type: "decimal(18,2)", nullable: false),
                    sec_insert_uid = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    sec_insert_date = table.Column<DateTime>(type: "datetime2", nullable: true),
                    sec_update_uid = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    sec_update_date = table.Column<DateTime>(type: "datetime2", nullable: true),
                    pharm_id = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Customer_Items", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "Customer_Points_Calc",
                columns: table => new
                {
                    id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    cpc_cust_id = table.Column<decimal>(type: "decimal(18,2)", nullable: false),
                    cpc_io_id = table.Column<short>(type: "smallint", nullable: false),
                    cpc_value = table.Column<short>(type: "smallint", nullable: true),
                    cpc_insert_uid = table.Column<int>(type: "int", nullable: true),
                    cpc_insert_date = table.Column<DateTime>(type: "datetime2", nullable: true),
                    cpc_update_uid = table.Column<int>(type: "int", nullable: true),
                    cpc_update_date = table.Column<DateTime>(type: "datetime2", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Customer_Points_Calc", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "Customer_Rules",
                columns: table => new
                {
                    id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    cr_id = table.Column<decimal>(type: "decimal(18,2)", nullable: false),
                    cr_cust_id = table.Column<decimal>(type: "decimal(18,2)", nullable: true),
                    cr_reach_value = table.Column<decimal>(type: "decimal(18,2)", nullable: true),
                    cr_disc_value = table.Column<decimal>(type: "decimal(18,2)", nullable: true),
                    cr_disc_perc = table.Column<decimal>(type: "decimal(18,2)", nullable: true),
                    cr_description = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    cr_start_date = table.Column<DateTime>(type: "datetime2", nullable: true),
                    cr_end_date = table.Column<DateTime>(type: "datetime2", nullable: true),
                    cr_period = table.Column<int>(type: "int", nullable: true),
                    cr_active = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    cr_no_of_times = table.Column<int>(type: "int", nullable: true),
                    sec_insert_uid = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    sec_insert_date = table.Column<DateTime>(type: "datetime2", nullable: true),
                    sec_update_uid = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    sec_update_date = table.Column<DateTime>(type: "datetime2", nullable: true),
                    pharm_id = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Customer_Rules", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "Customer_Type",
                columns: table => new
                {
                    id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    ct_id = table.Column<decimal>(type: "decimal(18,2)", nullable: false),
                    ct_name_ar = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    ct_name_en = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    sec_insert_uid = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    sec_insert_date = table.Column<DateTime>(type: "datetime2", nullable: true),
                    sec_update_uid = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    sec_update_date = table.Column<DateTime>(type: "datetime2", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Customer_Type", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "Customer_Visa",
                columns: table => new
                {
                    id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    cv_cust_id = table.Column<decimal>(type: "decimal(18,2)", nullable: false),
                    cv_id = table.Column<decimal>(type: "decimal(18,2)", nullable: false),
                    cv_name = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    cv_bank_id = table.Column<decimal>(type: "decimal(18,2)", nullable: true),
                    cv_number = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    cv_expire = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    cv_active = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    sec_insert_uid = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    sec_insert_date = table.Column<DateTime>(type: "datetime2", nullable: true),
                    sec_update_uid = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    sec_update_date = table.Column<DateTime>(type: "datetime2", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Customer_Visa", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "deleveryinformation",
                columns: table => new
                {
                    id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    sdi_id = table.Column<decimal>(type: "decimal(18,2)", nullable: false),
                    sth_id = table.Column<decimal>(type: "decimal(18,2)", nullable: false),
                    cust_id = table.Column<decimal>(type: "decimal(18,2)", nullable: true),
                    address = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    tel = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    contact = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    deliv_emp_id = table.Column<decimal>(type: "decimal(18,2)", nullable: true),
                    temp_col1 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    sec_insert_uid = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    sec_insert_date = table.Column<DateTime>(type: "datetime2", nullable: true),
                    sec_update_uid = table.Column<decimal>(type: "decimal(18,2)", nullable: true),
                    sec_update_date = table.Column<DateTime>(type: "datetime2", nullable: true),
                    deliv_emp_acc_id = table.Column<decimal>(type: "decimal(18,2)", nullable: true),
                    pharm_id = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    mov_id = table.Column<int>(type: "int", nullable: true),
                    Employ_Name = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    employname = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    pharmname = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    pharm_code = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    total_bill = table.Column<decimal>(type: "decimal(18,2)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_deleveryinformation", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "Deposit",
                columns: table => new
                {
                    Deposit_id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Deposit_Date = table.Column<DateTime>(type: "datetime2", nullable: true),
                    Deposit_qty = table.Column<decimal>(type: "decimal(18,2)", nullable: true),
                    Deposit_Bank = table.Column<int>(type: "int", nullable: true),
                    Deposit_Account_no = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Deposit_Slip_NO = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Deposit_Not = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Deposit", x => x.Deposit_id);
                });

            migrationBuilder.CreateTable(
                name: "Deposit_Bank",
                columns: table => new
                {
                    Bank_id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Bank_Name = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Deposit_Bank", x => x.Bank_id);
                });

            migrationBuilder.CreateTable(
                name: "Education",
                columns: table => new
                {
                    Education_id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Education_name = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Education", x => x.Education_id);
                });

            migrationBuilder.CreateTable(
                name: "Employ",
                columns: table => new
                {
                    emp_id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    emp_name = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    emp_hirdate = table.Column<DateTime>(type: "datetime2", nullable: true),
                    emp_tel = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    emp_mobile = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    emp_adress = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Emp_location = table.Column<int>(type: "int", nullable: true),
                    Emp_finger = table.Column<int>(type: "int", nullable: true),
                    Emp_Jop = table.Column<int>(type: "int", nullable: true),
                    Emp_Education = table.Column<int>(type: "int", nullable: true),
                    Emp_hPrice = table.Column<decimal>(type: "decimal(18,2)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Employ", x => x.emp_id);
                });

            migrationBuilder.CreateTable(
                name: "Employ_ledger",
                columns: table => new
                {
                    ID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Employ_machin_code = table.Column<int>(type: "int", nullable: false),
                    Pharm_id = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Invoice_id = table.Column<int>(type: "int", nullable: false),
                    Trans_Date = table.Column<DateTime>(type: "datetime2", nullable: true),
                    Depit = table.Column<decimal>(type: "decimal(18,2)", nullable: false),
                    Creadit = table.Column<decimal>(type: "decimal(18,2)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Employ_ledger", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "employhistory",
                columns: table => new
                {
                    id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Name = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Location = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Jop = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Hairdate = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Salary = table.Column<double>(type: "float", nullable: true),
                    Month = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Year = table.Column<double>(type: "float", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_employhistory", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "FinancialStatements",
                columns: table => new
                {
                    Code = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Name = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    AddedBy = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    DateUpdate = table.Column<DateTime>(type: "datetime2", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_FinancialStatements", x => x.Code);
                });

            migrationBuilder.CreateTable(
                name: "FSDetails",
                columns: table => new
                {
                    Code = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Description = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    AccCode = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    AccType = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    AddedBy = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    DateUpdate = table.Column<DateTime>(type: "datetime2", nullable: true),
                    GroupType = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    MainGroup = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    CalcGroup = table.Column<int>(type: "int", nullable: true),
                    Operation = table.Column<short>(type: "smallint", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_FSDetails", x => x.Code);
                });

            migrationBuilder.CreateTable(
                name: "GeneralLedger",
                columns: table => new
                {
                    TransNO = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    TransDate = table.Column<DateTime>(type: "datetime2", nullable: true),
                    TransType = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    ACCOrder = table.Column<int>(type: "int", nullable: true),
                    TreasuryCode = table.Column<int>(type: "int", nullable: true),
                    ReceiptNO = table.Column<int>(type: "int", nullable: true),
                    ACCcountCode = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Description = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Currancy = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Rate = table.Column<double>(type: "float", nullable: true),
                    BankAccount = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    ChequeNO = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Amount = table.Column<double>(type: "float", nullable: true),
                    Depit = table.Column<double>(type: "float", nullable: true),
                    Credit = table.Column<double>(type: "float", nullable: true),
                    Depit1 = table.Column<double>(type: "float", nullable: true),
                    Credit1 = table.Column<double>(type: "float", nullable: true),
                    Notes = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    VNote = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Posting = table.Column<bool>(type: "bit", nullable: true),
                    PostingDate = table.Column<DateTime>(type: "datetime2", nullable: true),
                    AddedBy = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    AddedDate = table.Column<DateTime>(type: "datetime2", nullable: true),
                    UpdatedBy = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    UpdatedDate = table.Column<DateTime>(type: "datetime2", nullable: true),
                    DueDate = table.Column<DateTime>(type: "datetime2", nullable: true),
                    REF = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    CostCenter = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_GeneralLedger", x => x.TransNO);
                });

            migrationBuilder.CreateTable(
                name: "Group",
                columns: table => new
                {
                    g_id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    g_name_ar = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    g_name_en = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    g_parent = table.Column<int>(type: "int", nullable: true),
                    sec_insert_uid = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    sec_insert_date = table.Column<DateTime>(type: "datetime2", nullable: true),
                    sec_update_uid = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    sec_update_date = table.Column<DateTime>(type: "datetime2", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Group", x => x.g_id);
                });

            migrationBuilder.CreateTable(
                name: "inersales_trans_d",
                columns: table => new
                {
                    ptd_id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    pth_id = table.Column<int>(type: "int", nullable: false),
                    itm_id = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    c_id = table.Column<int>(type: "int", nullable: false),
                    exp_date = table.Column<DateTime>(type: "datetime2", nullable: true),
                    qnty = table.Column<double>(type: "float", nullable: false),
                    bonus = table.Column<double>(type: "float", nullable: true),
                    itm_sell = table.Column<decimal>(type: "decimal(18,2)", nullable: true),
                    itm_pur_price = table.Column<decimal>(type: "decimal(18,2)", nullable: true),
                    itm_tax_price = table.Column<decimal>(type: "decimal(18,2)", nullable: true),
                    itm_tax_total = table.Column<decimal>(type: "decimal(18,2)", nullable: true),
                    itm_extra_dis = table.Column<decimal>(type: "decimal(18,2)", nullable: true),
                    itm_dis_mon = table.Column<decimal>(type: "decimal(18,2)", nullable: true),
                    itm_dis_per = table.Column<double>(type: "float", nullable: true),
                    itm_cost = table.Column<decimal>(type: "decimal(18,2)", nullable: true),
                    itm_net = table.Column<decimal>(type: "decimal(18,2)", nullable: true),
                    mov_id = table.Column<int>(type: "int", nullable: true),
                    unit_id = table.Column<int>(type: "int", nullable: true),
                    std_itm_stock = table.Column<double>(type: "float", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_inersales_trans_d", x => x.ptd_id);
                });

            migrationBuilder.CreateTable(
                name: "inersales_trans_h",
                columns: table => new
                {
                    id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    mov_id = table.Column<int>(type: "int", nullable: true),
                    Account_Entry = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    pth_id = table.Column<int>(type: "int", nullable: false),
                    sto_id = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    ven_id = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    no_of_items = table.Column<decimal>(type: "decimal(18,2)", nullable: true),
                    total_bill = table.Column<decimal>(type: "decimal(18,2)", nullable: true),
                    total_dis_per = table.Column<double>(type: "float", nullable: true),
                    total_des_mon = table.Column<decimal>(type: "decimal(18,2)", nullable: true),
                    total_tax = table.Column<decimal>(type: "decimal(18,2)", nullable: true),
                    p_other_expenses = table.Column<decimal>(type: "decimal(18,2)", nullable: true),
                    pth_net_bill = table.Column<decimal>(type: "decimal(18,2)", nullable: true),
                    pth_notice = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    ven_bill_no = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    ven_bill_date = table.Column<DateTime>(type: "datetime2", nullable: true),
                    pht_date = table.Column<DateTime>(type: "datetime2", nullable: true),
                    pht_clint = table.Column<int>(type: "int", nullable: true),
                    user_id_insert = table.Column<int>(type: "int", nullable: true),
                    insert_time = table.Column<DateTime>(type: "datetime2", nullable: true),
                    user_id_update = table.Column<int>(type: "int", nullable: true),
                    update_time = table.Column<DateTime>(type: "datetime2", nullable: true),
                    mov_stat = table.Column<int>(type: "int", nullable: true),
                    mov_account = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    mov_accountsec = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    accountBalance = table.Column<double>(type: "float", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_inersales_trans_h", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "info",
                columns: table => new
                {
                    id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Employ_Name = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Employ_michin_code = table.Column<int>(type: "int", nullable: true),
                    Employ_pharm = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Employ_hour_salary = table.Column<decimal>(type: "decimal(18,2)", nullable: true),
                    Employ_frist_time = table.Column<TimeSpan>(type: "time", nullable: true),
                    Employ_out_time = table.Column<TimeSpan>(type: "time", nullable: true),
                    Employ_jop = table.Column<int>(type: "int", nullable: true),
                    pharm_code = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    activemp = table.Column<int>(type: "int", nullable: true),
                    pharm_insh = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_info", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "InterCode",
                columns: table => new
                {
                    id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Item_Code = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Inter_Code = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_InterCode", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "inventory_d",
                columns: table => new
                {
                    id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    mov_id = table.Column<int>(type: "int", nullable: true),
                    fat_id = table.Column<int>(type: "int", nullable: true),
                    itm_code = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    exp_date = table.Column<DateTime>(type: "datetime2", nullable: true),
                    itm_sal_price = table.Column<decimal>(type: "decimal(18,2)", nullable: true),
                    itm_p_price = table.Column<decimal>(type: "decimal(18,2)", nullable: true),
                    itm_q = table.Column<decimal>(type: "decimal(18,2)", nullable: true),
                    itm_stock_qty = table.Column<decimal>(type: "decimal(18,2)", nullable: true),
                    itm_incres_qty = table.Column<decimal>(type: "decimal(18,2)", nullable: true),
                    item_short_qty = table.Column<decimal>(type: "decimal(18,2)", nullable: true),
                    unit_id = table.Column<int>(type: "int", nullable: true),
                    std_itm_stock = table.Column<double>(type: "float", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_inventory_d", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "inventory_h",
                columns: table => new
                {
                    id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    mov_id = table.Column<int>(type: "int", nullable: true),
                    fh_id = table.Column<int>(type: "int", nullable: true),
                    inv_dat = table.Column<DateTime>(type: "datetime2", nullable: true),
                    inv_store = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    inv_act_qty = table.Column<decimal>(type: "decimal(18,2)", nullable: true),
                    inv_act_total_sal_price = table.Column<decimal>(type: "decimal(18,2)", nullable: true),
                    inv_act_total_p_price = table.Column<decimal>(type: "decimal(18,2)", nullable: true),
                    inv_Total_stock_qty = table.Column<decimal>(type: "decimal(18,2)", nullable: true),
                    inv_Total_incres_qty = table.Column<decimal>(type: "decimal(18,2)", nullable: true),
                    inv_Total_short_qty = table.Column<decimal>(type: "decimal(18,2)", nullable: true),
                    inv_act_total_sal_price_incres = table.Column<decimal>(type: "decimal(18,2)", nullable: true),
                    inv_act_total_sal_price_short = table.Column<decimal>(type: "decimal(18,2)", nullable: true),
                    inv_act_total_p_price_incress = table.Column<decimal>(type: "decimal(18,2)", nullable: true),
                    inv_act_total_p_price_short = table.Column<decimal>(type: "decimal(18,2)", nullable: true),
                    inv_account1 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    inv_account2 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    inv_account3 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    inv_account4 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    user_insert_id = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    insert_date = table.Column<DateTime>(type: "datetime2", nullable: true),
                    user_update_id = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    update_time = table.Column<DateTime>(type: "datetime2", nullable: true),
                    mov_stat = table.Column<int>(type: "int", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_inventory_h", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "Item_Catalog",
                columns: table => new
                {
                    ID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    itm_id = table.Column<decimal>(type: "decimal(18,2)", nullable: false),
                    itm_code = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    itm_code2 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    itm_int_code = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    itm_usr_code = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    itm_name_ar = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    itm_name_en = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    com_id = table.Column<decimal>(type: "decimal(18,2)", nullable: true),
                    itm_com_code = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    itm_has_expire = table.Column<int>(type: "int", nullable: true),
                    itm_ismedicine = table.Column<int>(type: "int", nullable: true),
                    itm_location = table.Column<decimal>(type: "decimal(18,2)", nullable: true),
                    itm_request_limit = table.Column<decimal>(type: "decimal(18,2)", nullable: true),
                    itm_max_limit = table.Column<decimal>(type: "decimal(18,2)", nullable: true),
                    itm_min_limit = table.Column<decimal>(type: "decimal(18,2)", nullable: true),
                    itm_default_limit = table.Column<decimal>(type: "decimal(18,2)", nullable: true),
                    itm_purchase_unit = table.Column<decimal>(type: "decimal(18,2)", nullable: true),
                    itm_sell_unit = table.Column<decimal>(type: "decimal(18,2)", nullable: true),
                    itm_def_sell_price = table.Column<decimal>(type: "decimal(18,2)", nullable: true),
                    itm_def_tax = table.Column<decimal>(type: "decimal(18,2)", nullable: true),
                    itm_def_pharm_price = table.Column<decimal>(type: "decimal(18,2)", nullable: true),
                    itm_active = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    itm_unit1 = table.Column<decimal>(type: "decimal(18,2)", nullable: true),
                    itm_unit2 = table.Column<decimal>(type: "decimal(18,2)", nullable: true),
                    itm_unit3 = table.Column<decimal>(type: "decimal(18,2)", nullable: true),
                    itm_unit1_unit2 = table.Column<decimal>(type: "decimal(18,2)", nullable: true),
                    itm_unit1_unit3 = table.Column<decimal>(type: "decimal(18,2)", nullable: true),
                    itm_freez = table.Column<int>(type: "int", nullable: true),
                    itm_scientific_n1 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    itm_scientific_n2 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    itm_g1 = table.Column<decimal>(type: "decimal(18,2)", nullable: true),
                    itm_g2 = table.Column<decimal>(type: "decimal(18,2)", nullable: true),
                    itm_g3 = table.Column<decimal>(type: "decimal(18,2)", nullable: true),
                    itm_scientific_group_id = table.Column<decimal>(type: "decimal(18,2)", nullable: true),
                    itm_usage_manner_id = table.Column<decimal>(type: "decimal(18,2)", nullable: true),
                    itm_effictive = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    itm_effictive_perc = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    itm_isprev = table.Column<int>(type: "int", nullable: true),
                    itm_itf_id = table.Column<decimal>(type: "decimal(18,2)", nullable: true),
                    itm_stop_sell = table.Column<int>(type: "int", nullable: true),
                    itm_stop_pur = table.Column<int>(type: "int", nullable: true),
                    itm_print_barcode = table.Column<int>(type: "int", nullable: true),
                    itm_allow_discount = table.Column<int>(type: "int", nullable: true),
                    itm_max_disc_per = table.Column<double>(type: "float", nullable: true),
                    itm_max_disc_val = table.Column<double>(type: "float", nullable: true),
                    itm_print_name = table.Column<int>(type: "int", nullable: true),
                    itm_sales_avreage_period = table.Column<int>(type: "int", nullable: true),
                    itm_purchase_avreage_period = table.Column<int>(type: "int", nullable: true),
                    itm_srvc = table.Column<int>(type: "int", nullable: true),
                    itm_origin = table.Column<int>(type: "int", nullable: true),
                    itm_isShortage = table.Column<int>(type: "int", nullable: true),
                    itm_mid_unit_dif = table.Column<decimal>(type: "decimal(18,2)", nullable: true),
                    itm_small_unit_dif = table.Column<decimal>(type: "decimal(18,2)", nullable: true),
                    sec_insert_uid = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    sec_insert_date = table.Column<DateTime>(type: "datetime2", nullable: true),
                    sec_update_uid = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    sec_update_date = table.Column<DateTime>(type: "datetime2", nullable: true),
                    itm_frac_qty = table.Column<int>(type: "int", nullable: true),
                    itm_favourite = table.Column<int>(type: "int", nullable: true),
                    ucp_code = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    itm_notes = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    itm_sales_disc = table.Column<decimal>(type: "decimal(18,2)", nullable: true),
                    itm_nopurreturn = table.Column<int>(type: "int", nullable: true),
                    itm_price_updated = table.Column<int>(type: "int", nullable: true),
                    itm_sell_nostock = table.Column<int>(type: "int", nullable: true),
                    itm_G_id = table.Column<int>(type: "int", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Item_Catalog", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "Item_Chlied",
                columns: table => new
                {
                    id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Father_code = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Chiled_code = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Item_Chlied", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "Item_Objects",
                columns: table => new
                {
                    io_id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    io_itm_id = table.Column<decimal>(type: "decimal(18,2)", nullable: false),
                    io_itm_int = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    sec_insert_uid = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    sec_insert_date = table.Column<DateTime>(type: "datetime2", nullable: true),
                    sec_update_uid = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    sec_update_date = table.Column<DateTime>(type: "datetime2", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Item_Objects", x => x.io_id);
                });

            migrationBuilder.CreateTable(
                name: "Item_Origins",
                columns: table => new
                {
                    io_id = table.Column<short>(type: "smallint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    io_text_ar = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Item_Origins", x => x.io_id);
                });

            migrationBuilder.CreateTable(
                name: "item_usage_manner",
                columns: table => new
                {
                    ium_id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    ium_code = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    ium_name_ar = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    ium_name_en = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    sec_insert_uid = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    sec_insert_date = table.Column<DateTime>(type: "datetime2", nullable: true),
                    sec_update_uid = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    sec_update_date = table.Column<DateTime>(type: "datetime2", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_item_usage_manner", x => x.ium_id);
                });

            migrationBuilder.CreateTable(
                name: "ITEMSELECTED",
                columns: table => new
                {
                    ID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    ITM_CODE = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    ITM_AR_NAME = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    ITM_USER = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ITEMSELECTED", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "kit",
                columns: table => new
                {
                    id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    ItemMasterCode = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    ItemMasterUnit = table.Column<int>(type: "int", nullable: true),
                    ItemMasterqnty = table.Column<double>(type: "float", nullable: true),
                    ItemChiledCode = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    ItemChiledUnit = table.Column<int>(type: "int", nullable: true),
                    Itemchiledqty = table.Column<double>(type: "float", nullable: true),
                    user_insert = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Insert_time = table.Column<DateTime>(type: "datetime2", nullable: true),
                    update_time = table.Column<DateTime>(type: "datetime2", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_kit", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "kpitable",
                columns: table => new
                {
                    id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    pharm_id = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    mov_id = table.Column<int>(type: "int", nullable: true),
                    dat = table.Column<DateTime>(type: "datetime2", nullable: true),
                    pharmname = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Total_cash = table.Column<decimal>(type: "decimal(18,2)", nullable: false),
                    Total_post = table.Column<decimal>(type: "decimal(18,2)", nullable: false),
                    Total_visa = table.Column<decimal>(type: "decimal(18,2)", nullable: false),
                    Total_delevery = table.Column<decimal>(type: "decimal(18,2)", nullable: false),
                    Total_Contract = table.Column<decimal>(type: "decimal(18,2)", nullable: false),
                    Total_Medicin = table.Column<decimal>(type: "decimal(18,2)", nullable: false),
                    Total_DADY = table.Column<decimal>(type: "decimal(18,2)", nullable: true),
                    Total_Non_medicin = table.Column<decimal>(type: "decimal(18,2)", nullable: false),
                    returnsales = table.Column<decimal>(type: "decimal(18,2)", nullable: false),
                    Total_Not = table.Column<decimal>(type: "decimal(18,2)", nullable: false),
                    avt = table.Column<decimal>(type: "decimal(18,2)", nullable: false),
                    Noi = table.Column<decimal>(type: "decimal(18,2)", nullable: false),
                    del_NoT = table.Column<decimal>(type: "decimal(18,2)", nullable: false),
                    avdeltrans = table.Column<decimal>(type: "decimal(18,2)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_kpitable", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "Loan",
                columns: table => new
                {
                    LoanID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Type = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Description = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    BankName = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    LoanName = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    StartingDate = table.Column<DateTime>(type: "datetime2", nullable: true),
                    NoOfInstallment = table.Column<int>(type: "int", nullable: true),
                    LoanPrincipal = table.Column<double>(type: "float", nullable: true),
                    InstallmentAmount = table.Column<double>(type: "float", nullable: true),
                    Costcenter = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    AddedBy = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    DateUpdate = table.Column<DateTime>(type: "datetime2", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Loan", x => x.LoanID);
                });

            migrationBuilder.CreateTable(
                name: "LoanDetails",
                columns: table => new
                {
                    LoanID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    installmentNO = table.Column<int>(type: "int", nullable: false),
                    InstallmentDate = table.Column<DateTime>(type: "datetime2", nullable: true),
                    Amount = table.Column<double>(type: "float", nullable: true),
                    paid = table.Column<bool>(type: "bit", nullable: true),
                    paymentNo = table.Column<int>(type: "int", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_LoanDetails", x => x.LoanID);
                });

            migrationBuilder.CreateTable(
                name: "meetupdata",
                columns: table => new
                {
                    id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    title = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Image = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    address = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    description = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_meetupdata", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "Payable",
                columns: table => new
                {
                    ReceiptNO = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    ReceiptDate = table.Column<DateTime>(type: "datetime2", nullable: true),
                    Chequeno = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Name = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    BankCode = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    AccountNOCode = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Value = table.Column<double>(type: "float", nullable: true),
                    Currency = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    DueDate = table.Column<DateTime>(type: "datetime2", nullable: true),
                    AmountString = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    SignName = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Collected = table.Column<bool>(type: "bit", nullable: true),
                    CollectedDate = table.Column<DateTime>(type: "datetime2", nullable: true),
                    CollectedUser = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Refused = table.Column<bool>(type: "bit", nullable: true),
                    RefusedDate = table.Column<DateTime>(type: "datetime2", nullable: true),
                    RefusedUser = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Cancel = table.Column<bool>(type: "bit", nullable: true),
                    CancelDate = table.Column<DateTime>(type: "datetime2", nullable: true),
                    CancelUser = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Notes = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    DebitCode = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Reason = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    ActionDate = table.Column<DateTime>(type: "datetime2", nullable: true),
                    AddedUser = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Dateupdate = table.Column<DateTime>(type: "datetime2", nullable: true),
                    CostCenter = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    CreditCode = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Payable", x => x.ReceiptNO);
                });

            migrationBuilder.CreateTable(
                name: "PaymentVoucher",
                columns: table => new
                {
                    ReceiptNO = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    RecRef = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    ReceiptDate = table.Column<DateTime>(type: "datetime2", nullable: true),
                    SaveCode = table.Column<int>(type: "int", nullable: true),
                    Amount = table.Column<double>(type: "float", nullable: true),
                    Currency = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Rate = table.Column<double>(type: "float", nullable: true),
                    Type = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    VSource = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    PaidToCode = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    PaidToName = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Description = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    AddedUser = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    AddedDate = table.Column<DateTime>(type: "datetime2", nullable: true),
                    Approved = table.Column<bool>(type: "bit", nullable: false),
                    ChequeNO = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    BankCode = table.Column<int>(type: "int", nullable: true),
                    DueDate = table.Column<DateTime>(type: "datetime2", nullable: true),
                    AccountNO = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    TotalString = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    CostCenter = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    BankAccount = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_PaymentVoucher", x => x.ReceiptNO);
                });

            migrationBuilder.CreateTable(
                name: "Pharm_Recive_D_PH",
                columns: table => new
                {
                    ID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    FATH_ID = table.Column<int>(type: "int", nullable: true),
                    MOV_ID = table.Column<int>(type: "int", nullable: true),
                    itm_id = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    EXP_DATE = table.Column<DateTime>(type: "datetime2", nullable: true),
                    C_ID = table.Column<int>(type: "int", nullable: true),
                    ITM_PURCH_PRICE = table.Column<double>(type: "float", nullable: true),
                    ITM_SALES_PRICE = table.Column<double>(type: "float", nullable: true),
                    ITM_COST_PRICE = table.Column<double>(type: "float", nullable: true),
                    ITM_QTY = table.Column<double>(type: "float", nullable: true),
                    ITM_UNIT = table.Column<int>(type: "int", nullable: true),
                    ITM_STOCK = table.Column<double>(type: "float", nullable: true),
                    INSERT_UID = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    INSERT_DATE = table.Column<DateTime>(type: "datetime2", nullable: true),
                    std_itm_stock = table.Column<double>(type: "float", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Pharm_Recive_D_PH", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "Pharm_Recive_H_PH",
                columns: table => new
                {
                    ID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    MOV_ID = table.Column<int>(type: "int", nullable: true),
                    MOV_FATH_ID = table.Column<int>(type: "int", nullable: true),
                    MOV_STOR = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    MOV_DIS = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    MOV_TOTAL_QTY = table.Column<decimal>(type: "decimal(18,2)", nullable: true),
                    MOV_TOTAL_SALES_PRICE = table.Column<decimal>(type: "decimal(18,2)", nullable: true),
                    MOV_TOTAL_PURCH_PRICE = table.Column<decimal>(type: "decimal(18,2)", nullable: true),
                    MOV_TOTAL_COST_PRICE = table.Column<decimal>(type: "decimal(18,2)", nullable: true),
                    MOV_TOTAL_TAX_PRICE = table.Column<decimal>(type: "decimal(18,2)", nullable: true),
                    MOV_DATE = table.Column<DateTime>(type: "datetime2", nullable: true),
                    MOV_NOT = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    MOV_FLAG = table.Column<double>(type: "float", nullable: true),
                    MOV_ACCOUNT_DEPT1 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    MOV_ACCOUNT_DEPT2 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    MOV_ACCOUNT_DEPT3 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    MOV_ACCOUNT_DEPT4 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    MOV_ACCOUNT_CREDIT1 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    MOV_ACCOUNT_CREDIT2 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    MOV_ACCOUNT_CREDIT3 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    MOV_ACCOUNT_CREDIT4 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    insert_uid = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    insert_date = table.Column<DateTime>(type: "datetime2", nullable: true),
                    update_uid = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    update_date = table.Column<DateTime>(type: "datetime2", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Pharm_Recive_H_PH", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "PHARM_TRAN_D",
                columns: table => new
                {
                    ID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    SERIAL = table.Column<int>(type: "int", nullable: true),
                    FATHER_ID = table.Column<int>(type: "int", nullable: true),
                    ITM_ID = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    EXP_DATE = table.Column<DateTime>(type: "datetime2", nullable: true),
                    UNIT_ID = table.Column<int>(type: "int", nullable: true),
                    QTY = table.Column<double>(type: "float", nullable: true),
                    SALES_PRICE = table.Column<double>(type: "float", nullable: true),
                    USER_ID = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    INSERT_DATE = table.Column<DateTime>(type: "datetime2", nullable: true),
                    PURCH_PRICE = table.Column<decimal>(type: "decimal(18,2)", nullable: true),
                    std_itm_stock = table.Column<double>(type: "float", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_PHARM_TRAN_D", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "PHARM_TRAN_H",
                columns: table => new
                {
                    id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    TRA_PH_SOURC_ID = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    TRA_PH_DES_ID = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    TRA_PH_SOURC_STOR = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    TRA_PH_DES_STOR = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    TRA_DATE = table.Column<DateTime>(type: "datetime2", nullable: true),
                    TRA_TOTALQ = table.Column<double>(type: "float", nullable: true),
                    TRA_TOTALP = table.Column<double>(type: "float", nullable: true),
                    TRA_USER_ID = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    TRA_INSERT_DATE = table.Column<DateTime>(type: "datetime2", nullable: true),
                    TRA_UPDATE_USER = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    TRA_UPDATE_DATETIME = table.Column<DateTime>(type: "datetime2", nullable: true),
                    TRA_DEPT = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    TRA_CREDIT = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    TRA_FLAG = table.Column<int>(type: "int", nullable: true),
                    SEIAL = table.Column<int>(type: "int", nullable: true),
                    delver_id = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    note = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_PHARM_TRAN_H", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "Pharmcode",
                columns: table => new
                {
                    PharmCode = table.Column<string>(type: "nvarchar(450)", nullable: false),
                    pharmname = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Pharmcode", x => x.PharmCode);
                });

            migrationBuilder.CreateTable(
                name: "pur_trans_d",
                columns: table => new
                {
                    ptd_id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    pth_id = table.Column<int>(type: "int", nullable: false),
                    itm_id = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    c_id = table.Column<int>(type: "int", nullable: false),
                    exp_date = table.Column<DateTime>(type: "datetime2", nullable: true),
                    qnty = table.Column<double>(type: "float", nullable: false),
                    bonus = table.Column<double>(type: "float", nullable: true),
                    itm_sell = table.Column<decimal>(type: "decimal(18,2)", nullable: true),
                    itm_pur_price = table.Column<decimal>(type: "decimal(18,2)", nullable: true),
                    itm_tax_price = table.Column<decimal>(type: "decimal(18,2)", nullable: true),
                    itm_tax_total = table.Column<decimal>(type: "decimal(18,2)", nullable: true),
                    itm_extra_dis = table.Column<decimal>(type: "decimal(18,2)", nullable: true),
                    itm_dis_mon = table.Column<decimal>(type: "decimal(18,2)", nullable: true),
                    itm_dis_per = table.Column<double>(type: "float", nullable: true),
                    itm_cost = table.Column<decimal>(type: "decimal(18,2)", nullable: true),
                    itm_net = table.Column<decimal>(type: "decimal(18,2)", nullable: true),
                    mov_id = table.Column<int>(type: "int", nullable: true),
                    unit_id = table.Column<int>(type: "int", nullable: true),
                    std_itm_stock = table.Column<double>(type: "float", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_pur_trans_d", x => x.ptd_id);
                });

            migrationBuilder.CreateTable(
                name: "pur_trans_h",
                columns: table => new
                {
                    id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    mov_id = table.Column<int>(type: "int", nullable: true),
                    Account_Entry = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    pth_id = table.Column<int>(type: "int", nullable: false),
                    sto_id = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    ven_id = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    no_of_items = table.Column<decimal>(type: "decimal(18,2)", nullable: true),
                    total_bill = table.Column<decimal>(type: "decimal(18,2)", nullable: true),
                    total_dis_per = table.Column<double>(type: "float", nullable: true),
                    total_des_mon = table.Column<decimal>(type: "decimal(18,2)", nullable: true),
                    total_tax = table.Column<decimal>(type: "decimal(18,2)", nullable: true),
                    p_other_expenses = table.Column<decimal>(type: "decimal(18,2)", nullable: true),
                    pth_net_bill = table.Column<decimal>(type: "decimal(18,2)", nullable: true),
                    pth_notice = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    ven_bill_no = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    ven_bill_date = table.Column<DateTime>(type: "datetime2", nullable: true),
                    pht_date = table.Column<DateTime>(type: "datetime2", nullable: true),
                    pht_clint = table.Column<int>(type: "int", nullable: true),
                    user_id_insert = table.Column<int>(type: "int", nullable: true),
                    insert_time = table.Column<DateTime>(type: "datetime2", nullable: true),
                    user_id_update = table.Column<int>(type: "int", nullable: true),
                    update_time = table.Column<DateTime>(type: "datetime2", nullable: true),
                    mov_stat = table.Column<int>(type: "int", nullable: true),
                    mov_account = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    mov_accountsec = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    totalnettax = table.Column<decimal>(type: "decimal(18,2)", nullable: true),
                    mov_accounttherd = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    accountBalance = table.Column<double>(type: "float", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_pur_trans_h", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "return_trans_d",
                columns: table => new
                {
                    ptd_id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    pth_id = table.Column<int>(type: "int", nullable: false),
                    itm_id = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    c_id = table.Column<int>(type: "int", nullable: false),
                    exp_date = table.Column<DateTime>(type: "datetime2", nullable: true),
                    qnty = table.Column<double>(type: "float", nullable: false),
                    bonus = table.Column<double>(type: "float", nullable: true),
                    itm_sell = table.Column<decimal>(type: "decimal(18,2)", nullable: true),
                    itm_pur_price = table.Column<decimal>(type: "decimal(18,2)", nullable: true),
                    itm_tax_price = table.Column<decimal>(type: "decimal(18,2)", nullable: true),
                    itm_tax_total = table.Column<decimal>(type: "decimal(18,2)", nullable: true),
                    itm_extra_dis = table.Column<decimal>(type: "decimal(18,2)", nullable: true),
                    itm_dis_mon = table.Column<decimal>(type: "decimal(18,2)", nullable: true),
                    itm_dis_per = table.Column<decimal>(type: "decimal(18,2)", nullable: true),
                    itm_cost = table.Column<decimal>(type: "decimal(18,2)", nullable: true),
                    itm_net = table.Column<decimal>(type: "decimal(18,2)", nullable: true),
                    mov_id = table.Column<int>(type: "int", nullable: true),
                    unit_id = table.Column<int>(type: "int", nullable: true),
                    std_itm_stock = table.Column<double>(type: "float", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_return_trans_d", x => x.ptd_id);
                });

            migrationBuilder.CreateTable(
                name: "return_trans_h",
                columns: table => new
                {
                    id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    mov_id = table.Column<int>(type: "int", nullable: true),
                    Account_Entry = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    pth_id = table.Column<int>(type: "int", nullable: false),
                    sto_id = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    ven_id = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    no_of_items = table.Column<decimal>(type: "decimal(18,2)", nullable: true),
                    total_bill = table.Column<decimal>(type: "decimal(18,2)", nullable: true),
                    total_dis_per = table.Column<double>(type: "float", nullable: true),
                    total_des_mon = table.Column<decimal>(type: "decimal(18,2)", nullable: true),
                    total_tax = table.Column<decimal>(type: "decimal(18,2)", nullable: true),
                    p_other_expenses = table.Column<decimal>(type: "decimal(18,2)", nullable: true),
                    pth_net_bill = table.Column<decimal>(type: "decimal(18,2)", nullable: true),
                    pth_notice = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    ven_bill_no = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    ven_bill_date = table.Column<DateTime>(type: "datetime2", nullable: true),
                    pht_date = table.Column<DateTime>(type: "datetime2", nullable: true),
                    pht_clint = table.Column<int>(type: "int", nullable: true),
                    user_id_insert = table.Column<int>(type: "int", nullable: true),
                    insert_time = table.Column<DateTime>(type: "datetime2", nullable: true),
                    user_id_update = table.Column<int>(type: "int", nullable: true),
                    update_time = table.Column<DateTime>(type: "datetime2", nullable: true),
                    mov_stat = table.Column<int>(type: "int", nullable: true),
                    mov_account = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    mov_accountsec = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    accountBalance = table.Column<double>(type: "float", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_return_trans_h", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "sales_trans_d",
                columns: table => new
                {
                    id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    std_id = table.Column<decimal>(type: "decimal(18,2)", nullable: false),
                    sth_id = table.Column<decimal>(type: "decimal(18,2)", nullable: false),
                    itm_id = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    c_id = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    exp_date = table.Column<DateTime>(type: "datetime2", nullable: true),
                    qnty = table.Column<decimal>(type: "decimal(18,2)", nullable: false),
                    itm_unit = table.Column<int>(type: "int", nullable: true),
                    itm_sell = table.Column<decimal>(type: "decimal(18,2)", nullable: false),
                    itm_cost = table.Column<decimal>(type: "decimal(18,2)", nullable: true),
                    itm_dis_mon = table.Column<decimal>(type: "decimal(18,2)", nullable: true),
                    itm_dis_per = table.Column<double>(type: "float", nullable: true),
                    itm_back = table.Column<decimal>(type: "decimal(18,2)", nullable: true),
                    itm_back_price = table.Column<decimal>(type: "decimal(18,2)", nullable: true),
                    itm_aver_cost = table.Column<decimal>(type: "decimal(18,2)", nullable: true),
                    col1 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    col2 = table.Column<decimal>(type: "decimal(18,2)", nullable: true),
                    col3 = table.Column<double>(type: "float", nullable: true),
                    sec_insert_uid = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    sec_insert_date = table.Column<DateTime>(type: "datetime2", nullable: true),
                    sec_update_uid = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    sec_update_date = table.Column<DateTime>(type: "datetime2", nullable: true),
                    itm_nexist = table.Column<int>(type: "int", nullable: true),
                    std_itm_purchase_unit = table.Column<int>(type: "int", nullable: true),
                    std_itm_unit1_unit2 = table.Column<int>(type: "int", nullable: true),
                    std_itm_unit1_unit3 = table.Column<int>(type: "int", nullable: true),
                    std_itm_stock = table.Column<double>(type: "float", nullable: true),
                    std_r_itm_purchase_unit = table.Column<int>(type: "int", nullable: true),
                    std_r_itm_unit1_unit2 = table.Column<int>(type: "int", nullable: true),
                    std_r_itm_unit1_unit3 = table.Column<int>(type: "int", nullable: true),
                    std_r_itm_stock = table.Column<decimal>(type: "decimal(18,2)", nullable: true),
                    std_itm_origin = table.Column<int>(type: "int", nullable: true),
                    mov_id = table.Column<int>(type: "int", nullable: true),
                    TAX_PER_PICES = table.Column<decimal>(type: "decimal(18,2)", nullable: true),
                    vatsales = table.Column<decimal>(type: "decimal(18,2)", nullable: true),
                    defrentvat = table.Column<decimal>(type: "decimal(18,2)", nullable: true),
                    CONTRACT_TOTALVAL = table.Column<decimal>(type: "decimal(18,2)", nullable: true),
                    CONTRACT_discontvalue = table.Column<decimal>(type: "decimal(18,2)", nullable: true),
                    CONTRACT_paied = table.Column<decimal>(type: "decimal(18,2)", nullable: true),
                    CONTRACT_Credit = table.Column<decimal>(type: "decimal(18,2)", nullable: true),
                    PURCH_PRICE = table.Column<decimal>(type: "decimal(18,2)", nullable: true),
                    PHARM_ID = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    sales_net = table.Column<decimal>(type: "decimal(18,2)", nullable: true),
                    saleswithoutvit = table.Column<decimal>(type: "decimal(18,2)", nullable: true),
                    discount_per = table.Column<decimal>(type: "decimal(18,2)", nullable: false),
                    discount_val = table.Column<decimal>(type: "decimal(18,2)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_sales_trans_d", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "sales_trans_h",
                columns: table => new
                {
                    id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    sth_id = table.Column<decimal>(type: "decimal(18,2)", nullable: false),
                    sto_id = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    cust_id = table.Column<decimal>(type: "decimal(18,2)", nullable: true),
                    bill_typ = table.Column<int>(type: "int", nullable: true),
                    no_of_items = table.Column<decimal>(type: "decimal(18,2)", nullable: true),
                    no_of_items_exc = table.Column<int>(type: "int", nullable: true),
                    total_bill = table.Column<decimal>(type: "decimal(18,2)", nullable: true),
                    total_bill_after_disc = table.Column<decimal>(type: "decimal(18,2)", nullable: true),
                    total_bill_net = table.Column<decimal>(type: "decimal(18,2)", nullable: true),
                    total_bill_exc = table.Column<decimal>(type: "decimal(18,2)", nullable: true),
                    total_dis_per = table.Column<double>(type: "float", nullable: true),
                    total_des_mon = table.Column<decimal>(type: "decimal(18,2)", nullable: true),
                    emp_id = table.Column<decimal>(type: "decimal(18,2)", nullable: true),
                    sth_notice = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    sth_cash = table.Column<decimal>(type: "decimal(18,2)", nullable: true),
                    sth_rest = table.Column<decimal>(type: "decimal(18,2)", nullable: true),
                    sth_extra_expenses = table.Column<decimal>(type: "decimal(18,2)", nullable: true),
                    sth_flag = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    fh_id = table.Column<decimal>(type: "decimal(18,2)", nullable: true),
                    fh_contract_id = table.Column<decimal>(type: "decimal(18,2)", nullable: true),
                    fh_company_part = table.Column<decimal>(type: "decimal(18,2)", nullable: true),
                    fh_medins_rec_name = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    fh_medins_ticket_num = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    fh_medins_ins_num = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    fh_clinic_id = table.Column<decimal>(type: "decimal(18,2)", nullable: true),
                    fh_clinic_spec_id = table.Column<decimal>(type: "decimal(18,2)", nullable: true),
                    fh_doc_spec_id = table.Column<decimal>(type: "decimal(18,2)", nullable: true),
                    sth_back = table.Column<int>(type: "int", nullable: true),
                    delivery_date = table.Column<DateTime>(type: "datetime2", nullable: true),
                    temp_col3 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    temp_col4 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    temp_col5 = table.Column<int>(type: "int", nullable: true),
                    temp_col6 = table.Column<decimal>(type: "decimal(18,2)", nullable: true),
                    temp_col7 = table.Column<double>(type: "float", nullable: true),
                    temp_col8 = table.Column<decimal>(type: "decimal(18,2)", nullable: true),
                    sec_insert_uid = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    sec_insert_date = table.Column<DateTime>(type: "datetime2", nullable: true),
                    sec_update_uid = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    sec_update_date = table.Column<DateTime>(type: "datetime2", nullable: true),
                    sth_user_save_pend = table.Column<decimal>(type: "decimal(18,2)", nullable: true),
                    sth_delivery_rest = table.Column<decimal>(type: "decimal(18,2)", nullable: true),
                    sth_deliv_closed = table.Column<bool>(type: "bit", nullable: true),
                    fh_medins_Doc_name = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    sth_pc_name = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    sth_pont = table.Column<decimal>(type: "decimal(18,2)", nullable: true),
                    sth_pnt_dis = table.Column<decimal>(type: "decimal(18,2)", nullable: true),
                    sth_return_payment = table.Column<int>(type: "int", nullable: true),
                    mov_id = table.Column<int>(type: "int", nullable: true),
                    pharm_id = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Sc_Id = table.Column<int>(type: "int", nullable: true),
                    contractclint = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_sales_trans_h", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "stock",
                columns: table => new
                {
                    id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    item_id = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    exp_date = table.Column<DateTime>(type: "datetime2", nullable: true),
                    qty = table.Column<decimal>(type: "decimal(18,2)", nullable: true),
                    stor_id = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    pursh_price = table.Column<decimal>(type: "decimal(18,2)", nullable: true),
                    sales_price = table.Column<decimal>(type: "decimal(18,2)", nullable: true),
                    cost_price = table.Column<decimal>(type: "decimal(18,2)", nullable: true),
                    unit_id = table.Column<int>(type: "int", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_stock", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "AspNetRoleClaims",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    RoleId = table.Column<string>(type: "nvarchar(450)", nullable: false),
                    ClaimType = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    ClaimValue = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_AspNetRoleClaims", x => x.Id);
                    table.ForeignKey(
                        name: "FK_AspNetRoleClaims_AspNetRoles_RoleId",
                        column: x => x.RoleId,
                        principalTable: "AspNetRoles",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "AspNetUserClaims",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    UserId = table.Column<string>(type: "nvarchar(450)", nullable: false),
                    ClaimType = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    ClaimValue = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_AspNetUserClaims", x => x.Id);
                    table.ForeignKey(
                        name: "FK_AspNetUserClaims_AspNetUsers_UserId",
                        column: x => x.UserId,
                        principalTable: "AspNetUsers",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "AspNetUserLogins",
                columns: table => new
                {
                    LoginProvider = table.Column<string>(type: "nvarchar(450)", nullable: false),
                    ProviderKey = table.Column<string>(type: "nvarchar(450)", nullable: false),
                    ProviderDisplayName = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    UserId = table.Column<string>(type: "nvarchar(450)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_AspNetUserLogins", x => new { x.LoginProvider, x.ProviderKey });
                    table.ForeignKey(
                        name: "FK_AspNetUserLogins_AspNetUsers_UserId",
                        column: x => x.UserId,
                        principalTable: "AspNetUsers",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "AspNetUserRoles",
                columns: table => new
                {
                    UserId = table.Column<string>(type: "nvarchar(450)", nullable: false),
                    RoleId = table.Column<string>(type: "nvarchar(450)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_AspNetUserRoles", x => new { x.UserId, x.RoleId });
                    table.ForeignKey(
                        name: "FK_AspNetUserRoles_AspNetRoles_RoleId",
                        column: x => x.RoleId,
                        principalTable: "AspNetRoles",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_AspNetUserRoles_AspNetUsers_UserId",
                        column: x => x.UserId,
                        principalTable: "AspNetUsers",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "AspNetUserTokens",
                columns: table => new
                {
                    UserId = table.Column<string>(type: "nvarchar(450)", nullable: false),
                    LoginProvider = table.Column<string>(type: "nvarchar(450)", nullable: false),
                    Name = table.Column<string>(type: "nvarchar(450)", nullable: false),
                    Value = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_AspNetUserTokens", x => new { x.UserId, x.LoginProvider, x.Name });
                    table.ForeignKey(
                        name: "FK_AspNetUserTokens_AspNetUsers_UserId",
                        column: x => x.UserId,
                        principalTable: "AspNetUsers",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_AspNetRoleClaims_RoleId",
                table: "AspNetRoleClaims",
                column: "RoleId");

            migrationBuilder.CreateIndex(
                name: "RoleNameIndex",
                table: "AspNetRoles",
                column: "NormalizedName",
                unique: true,
                filter: "[NormalizedName] IS NOT NULL");

            migrationBuilder.CreateIndex(
                name: "IX_AspNetUserClaims_UserId",
                table: "AspNetUserClaims",
                column: "UserId");

            migrationBuilder.CreateIndex(
                name: "IX_AspNetUserLogins_UserId",
                table: "AspNetUserLogins",
                column: "UserId");

            migrationBuilder.CreateIndex(
                name: "IX_AspNetUserRoles_RoleId",
                table: "AspNetUserRoles",
                column: "RoleId");

            migrationBuilder.CreateIndex(
                name: "EmailIndex",
                table: "AspNetUsers",
                column: "NormalizedEmail");

            migrationBuilder.CreateIndex(
                name: "UserNameIndex",
                table: "AspNetUsers",
                column: "NormalizedUserName",
                unique: true,
                filter: "[NormalizedUserName] IS NOT NULL");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "ACCLeadger");

            migrationBuilder.DropTable(
                name: "ACCOUNTINSHS");

            migrationBuilder.DropTable(
                name: "AccountsChart");

            migrationBuilder.DropTable(
                name: "accountshortcutstor");

            migrationBuilder.DropTable(
                name: "ActionsCode");

            migrationBuilder.DropTable(
                name: "AspNetRoleClaims");

            migrationBuilder.DropTable(
                name: "AspNetUserClaims");

            migrationBuilder.DropTable(
                name: "AspNetUserLogins");

            migrationBuilder.DropTable(
                name: "AspNetUserRoles");

            migrationBuilder.DropTable(
                name: "AspNetUserTokens");

            migrationBuilder.DropTable(
                name: "Cheque");

            migrationBuilder.DropTable(
                name: "ChequeTemplate");

            migrationBuilder.DropTable(
                name: "CollectedVoucher");

            migrationBuilder.DropTable(
                name: "Company");

            migrationBuilder.DropTable(
                name: "Coupon");

            migrationBuilder.DropTable(
                name: "Currency");

            migrationBuilder.DropTable(
                name: "CurrencyHistory");

            migrationBuilder.DropTable(
                name: "Customer");

            migrationBuilder.DropTable(
                name: "Customer_branches");

            migrationBuilder.DropTable(
                name: "Customer_Contracts");

            migrationBuilder.DropTable(
                name: "customer_credit_chng");

            migrationBuilder.DropTable(
                name: "Customer_Delivery");

            migrationBuilder.DropTable(
                name: "Customer_Groups");

            migrationBuilder.DropTable(
                name: "Customer_Items");

            migrationBuilder.DropTable(
                name: "Customer_Points_Calc");

            migrationBuilder.DropTable(
                name: "Customer_Rules");

            migrationBuilder.DropTable(
                name: "Customer_Type");

            migrationBuilder.DropTable(
                name: "Customer_Visa");

            migrationBuilder.DropTable(
                name: "deleveryinformation");

            migrationBuilder.DropTable(
                name: "Deposit");

            migrationBuilder.DropTable(
                name: "Deposit_Bank");

            migrationBuilder.DropTable(
                name: "Education");

            migrationBuilder.DropTable(
                name: "Employ");

            migrationBuilder.DropTable(
                name: "Employ_ledger");

            migrationBuilder.DropTable(
                name: "employhistory");

            migrationBuilder.DropTable(
                name: "FinancialStatements");

            migrationBuilder.DropTable(
                name: "FSDetails");

            migrationBuilder.DropTable(
                name: "GeneralLedger");

            migrationBuilder.DropTable(
                name: "Group");

            migrationBuilder.DropTable(
                name: "inersales_trans_d");

            migrationBuilder.DropTable(
                name: "inersales_trans_h");

            migrationBuilder.DropTable(
                name: "info");

            migrationBuilder.DropTable(
                name: "InterCode");

            migrationBuilder.DropTable(
                name: "inventory_d");

            migrationBuilder.DropTable(
                name: "inventory_h");

            migrationBuilder.DropTable(
                name: "Item_Catalog");

            migrationBuilder.DropTable(
                name: "Item_Chlied");

            migrationBuilder.DropTable(
                name: "Item_Objects");

            migrationBuilder.DropTable(
                name: "Item_Origins");

            migrationBuilder.DropTable(
                name: "item_usage_manner");

            migrationBuilder.DropTable(
                name: "ITEMSELECTED");

            migrationBuilder.DropTable(
                name: "kit");

            migrationBuilder.DropTable(
                name: "kpitable");

            migrationBuilder.DropTable(
                name: "Loan");

            migrationBuilder.DropTable(
                name: "LoanDetails");

            migrationBuilder.DropTable(
                name: "meetupdata");

            migrationBuilder.DropTable(
                name: "Payable");

            migrationBuilder.DropTable(
                name: "PaymentVoucher");

            migrationBuilder.DropTable(
                name: "Pharm_Recive_D_PH");

            migrationBuilder.DropTable(
                name: "Pharm_Recive_H_PH");

            migrationBuilder.DropTable(
                name: "PHARM_TRAN_D");

            migrationBuilder.DropTable(
                name: "PHARM_TRAN_H");

            migrationBuilder.DropTable(
                name: "Pharmcode");

            migrationBuilder.DropTable(
                name: "pur_trans_d");

            migrationBuilder.DropTable(
                name: "pur_trans_h");

            migrationBuilder.DropTable(
                name: "return_trans_d");

            migrationBuilder.DropTable(
                name: "return_trans_h");

            migrationBuilder.DropTable(
                name: "sales_trans_d");

            migrationBuilder.DropTable(
                name: "sales_trans_h");

            migrationBuilder.DropTable(
                name: "stock");

            migrationBuilder.DropTable(
                name: "AspNetRoles");

            migrationBuilder.DropTable(
                name: "AspNetUsers");
        }
    }
}
