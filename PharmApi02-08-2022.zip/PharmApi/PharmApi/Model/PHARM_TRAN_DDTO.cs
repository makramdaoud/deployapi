﻿using System.ComponentModel.DataAnnotations;
using System;
namespace PharmApi.Model
{
    public class PHARM_TRAN_DDTO: CreatePHARM_TRAN_DDTO
    {
        public int ID { get; set; }
    }
    public class CreatePHARM_TRAN_DDTO
    {
      
        public Nullable<int> SERIAL { get; set; }
        public Nullable<int> FATHER_ID { get; set; }
        public string ITM_ID { get; set; }
        public Nullable<System.DateTime> EXP_DATE { get; set; }
        public Nullable<int> UNIT_ID { get; set; }
        public Nullable<double> QTY { get; set; }
        public Nullable<double> SALES_PRICE { get; set; }
        public string USER_ID { get; set; }
        public Nullable<System.DateTime> INSERT_DATE { get; set; }
        public Nullable<decimal> PURCH_PRICE { get; set; }
        public Nullable<double> std_itm_stock { get; set; }
    }
}
