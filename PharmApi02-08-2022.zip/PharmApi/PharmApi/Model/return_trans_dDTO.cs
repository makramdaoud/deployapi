﻿using System.ComponentModel.DataAnnotations;
using System;
namespace PharmApi.Model
{
    public class return_trans_dDTO: Createreturn_trans_dDTO
    {
        public int ptd_id { get; set; }
    }
    public class Createreturn_trans_dDTO
    {
    
        public int pth_id { get; set; }
        public string itm_id { get; set; }
        public int c_id { get; set; }
        public Nullable<System.DateTime> exp_date { get; set; }
        public double qnty { get; set; }
        public Nullable<double> bonus { get; set; }
        public Nullable<decimal> itm_sell { get; set; }
        public Nullable<decimal> itm_pur_price { get; set; }
        public Nullable<decimal> itm_tax_price { get; set; }
        public Nullable<decimal> itm_tax_total { get; set; }
        public Nullable<decimal> itm_extra_dis { get; set; }
        public Nullable<decimal> itm_dis_mon { get; set; }
        public Nullable<double> itm_dis_per { get; set; }
        public Nullable<decimal> itm_cost { get; set; }
        public Nullable<decimal> itm_net { get; set; }
        public Nullable<int> mov_id { get; set; }
        public Nullable<int> unit_id { get; set; }
        public Nullable<double> std_itm_stock { get; set; }
    }
}
