﻿namespace PharmApi.Model
{
    public class InterCodeDTO: CreateInterCodeDTO
    {
        public int id { get; set; }
    }
    public class CreateInterCodeDTO
    {

        public string Item_Code { get; set; }
        public string Inter_Code { get; set; }
    }
}
