﻿using System.ComponentModel.DataAnnotations;
using System;

namespace PharmApi.Model
{
    public class CurrencyDTO : CreateCurrencyDTO
    {
        public string Code { get; set; }
    }
    public class CreateCurrencyDTO
    {

        public string Name { get; set; }
        public double? Rate { get; set; }
        public string AddUser { get; set; }
        public DateTime? DateUpdate { get; set; }
        public int? Sort { get; set; }
        public double? EGPRate { get; set; }
        public int? FSort { get; set; }
    }
}
