﻿using System.ComponentModel.DataAnnotations;
using System;
namespace PharmApi.Model
{
    public class PaymentVoucherDTO: CreatePaymentVoucherDTO

    {
        public int ReceiptNO { get; set; }
    }
    public class  CreatePaymentVoucherDTO

    {

        public string RecRef { get; set; }
        public Nullable<System.DateTime> ReceiptDate { get; set; }
        public Nullable<int> SaveCode { get; set; }
        public Nullable<double> Amount { get; set; }
        public string Currency { get; set; }
        public Nullable<double> Rate { get; set; }
        public string Type { get; set; }
        public string VSource { get; set; }
        public string PaidToCode { get; set; }
        public string PaidToName { get; set; }
        public string Description { get; set; }
        public string AddedUser { get; set; }
        public Nullable<System.DateTime> AddedDate { get; set; }
        public bool Approved { get; set; }
        public string ChequeNO { get; set; }
        public Nullable<int> BankCode { get; set; }
        public Nullable<System.DateTime> DueDate { get; set; }
        public string AccountNO { get; set; }
        public string TotalString { get; set; }
        public string CostCenter { get; set; }
        public string BankAccount { get; set; }
    }
}
