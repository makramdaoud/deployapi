﻿using System.ComponentModel.DataAnnotations;
using System;
namespace PharmApi.Model
{
    public class Customer_branchesDTO: CreateCustomer_branchesDTO
    {
        public int id { get; set; }
    }
    public class CreateCustomer_branchesDTO
    {
        public decimal cb_id { get; set; }
        public string cb_code { get; set; }
        public string cb_name_ar { get; set; }
        public string cb_name_en { get; set; }
        public string cb_manager { get; set; }
        public string cb_address { get; set; }
        public string cb_tel { get; set; }
        public Nullable<decimal> cb_cust_id { get; set; }
        public string sec_insert_uid { get; set; }
        public Nullable<System.DateTime> sec_insert_date { get; set; }
        public string sec_update_uid { get; set; }
        public Nullable<System.DateTime> sec_update_date { get; set; }
        
        public string pharm_id { get; set; }
    }
}
