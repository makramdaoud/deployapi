﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace PharmApi.Model
{
    public class accountshortcutstorDTO: CreateaccountshortcutstorDTO
    {
        public int id { get; set; }
        
    }
    public class CreateaccountshortcutstorDTO
    {
   
        [Required]
        [StringLength(maximumLength: 5, ErrorMessage = "THE LENTH MUST BE ")]
        public string pharm_code { get; set; }
        public string pharmname { get; set; }
        public string StoreId { get; set; }
        public string Stor_Name { get; set; }
    }
}
