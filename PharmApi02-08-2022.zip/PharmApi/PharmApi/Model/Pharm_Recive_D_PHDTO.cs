﻿using System.ComponentModel.DataAnnotations;
using System;
namespace PharmApi.Model
{
    public class Pharm_Recive_D_PHDTO: CreatePharm_Recive_D_PHDTO
    {
        public decimal ID { get; set; }
    }
    public class CreatePharm_Recive_D_PHDTO
    {

        public Nullable<int> FATH_ID { get; set; }
        public Nullable<int> MOV_ID { get; set; }
        public string itm_id { get; set; }
        public Nullable<System.DateTime> EXP_DATE { get; set; }
        public Nullable<int> C_ID { get; set; }
        public Nullable<double> ITM_PURCH_PRICE { get; set; }
        public Nullable<double> ITM_SALES_PRICE { get; set; }
        public Nullable<double> ITM_COST_PRICE { get; set; }
        public Nullable<double> ITM_QTY { get; set; }
        public Nullable<int> ITM_UNIT { get; set; }
        public Nullable<double> ITM_STOCK { get; set; }
        public string INSERT_UID { get; set; }
        public Nullable<System.DateTime> INSERT_DATE { get; set; }
        public Nullable<double> std_itm_stock { get; set; }
    }
}
