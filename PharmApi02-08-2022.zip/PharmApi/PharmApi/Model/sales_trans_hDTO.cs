﻿using System.ComponentModel.DataAnnotations;
using System;
namespace PharmApi.Model
{
    public class sales_trans_hDTO: Createsales_trans_hDTO
    {
        public int id { get; set; }
    }
    public class Createsales_trans_hDTO
    {
        
        public decimal sth_id { get; set; }
        public string sto_id { get; set; }
        public Nullable<decimal> cust_id { get; set; }
        public Nullable<int> bill_typ { get; set; }
        public Nullable<decimal> no_of_items { get; set; }
        public Nullable<int> no_of_items_exc { get; set; }
        public Nullable<decimal> total_bill { get; set; }
        public Nullable<decimal> total_bill_after_disc { get; set; }
        public Nullable<decimal> total_bill_net { get; set; }
        public Nullable<decimal> total_bill_exc { get; set; }
        public Nullable<double> total_dis_per { get; set; }
        public Nullable<decimal> total_des_mon { get; set; }
        public Nullable<decimal> emp_id { get; set; }
        public string sth_notice { get; set; }
        public Nullable<decimal> sth_cash { get; set; }
        public Nullable<decimal> sth_rest { get; set; }
        public Nullable<decimal> sth_extra_expenses { get; set; }
        public string sth_flag { get; set; }
        public Nullable<decimal> fh_id { get; set; }
        public Nullable<decimal> fh_contract_id { get; set; }
        public Nullable<decimal> fh_company_part { get; set; }
        public string fh_medins_rec_name { get; set; }
        public string fh_medins_ticket_num { get; set; }
        public string fh_medins_ins_num { get; set; }
        public Nullable<decimal> fh_clinic_id { get; set; }
        public Nullable<decimal> fh_clinic_spec_id { get; set; }
        public Nullable<decimal> fh_doc_spec_id { get; set; }
        public Nullable<int> sth_back { get; set; }
        public Nullable<System.DateTime> delivery_date { get; set; }
        public string temp_col3 { get; set; }
        public string temp_col4 { get; set; }
        public Nullable<int> temp_col5 { get; set; }
        public Nullable<decimal> temp_col6 { get; set; }
        public Nullable<double> temp_col7 { get; set; }
        public Nullable<decimal> temp_col8 { get; set; }
        public string sec_insert_uid { get; set; }
        public Nullable<System.DateTime> sec_insert_date { get; set; }
        public string sec_update_uid { get; set; }
        public Nullable<System.DateTime> sec_update_date { get; set; }
        public Nullable<decimal> sth_user_save_pend { get; set; }
        public Nullable<decimal> sth_delivery_rest { get; set; }
        public Nullable<bool> sth_deliv_closed { get; set; }
        public string fh_medins_Doc_name { get; set; }
        public string sth_pc_name { get; set; }
        public Nullable<decimal> sth_pont { get; set; }
        public Nullable<decimal> sth_pnt_dis { get; set; }
        public Nullable<int> sth_return_payment { get; set; }
        public Nullable<int> mov_id { get; set; }
        public string pharm_id { get; set; }
        public Nullable<int> Sc_Id { get; set; }
        public string contractclint { get; set; }
    }
}
