﻿using System.ComponentModel.DataAnnotations;
using System;
namespace PharmApi.Model
{
    public class CouponDTO: CreateCouponDTO
    {
        public decimal cou_Id { get; set; }
    }
    public class CreateCouponDTO
    {

        public decimal cust_id { get; set; }
        public decimal bill_id { get; set; }
        public Nullable<decimal> total_cach { get; set; }
        public Nullable<decimal> actual_total_cash { get; set; }
        public Nullable<decimal> total_bill_cash { get; set; }
        public Nullable<decimal> total_bill_cash_exch { get; set; }
        public Nullable<System.DateTime> sec_insert_date { get; set; }
        public string sec_insert_uid { get; set; }
        public Nullable<System.DateTime> sec_update_date { get; set; }
        public string sec_update_uid { get; set; }
        public string recipient_name { get; set; }
        public string status { get; set; }
        public Nullable<int> coup_form { get; set; }
        public int id { get; set; }
        public Nullable<int> mov_id { get; set; }
    }
}
