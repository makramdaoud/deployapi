﻿using System.ComponentModel.DataAnnotations;
using System;
namespace PharmApi.Model
{
    public class Customer_ContractsDTO: CreateCustomer_ContractsDTO
    {
        public int id { get; set; }
    }
    public class CreateCustomer_ContractsDTO
    {
        public decimal cc_id { get; set; }
        public decimal cc_cust_id { get; set; }
        public string cc_number { get; set; }
        public string cc_name { get; set; }

        public decimal cc_max_bill_value { get; set; }
      
        public decimal cc_dis_perc { get; set; }
        
        public decimal cc_dis_per_for_cust { get; set; }

        public decimal cc_pay_perc { get; set; }

        public int cc_pay_perc_rule { get; set; }
       
        public decimal cc_extra_discount { get; set; }
        public int cc_active { get; set; }

        public decimal cc_local_items_disc { get; set; }
      
        public decimal cc_imported_items_disc { get; set; }
  
        public decimal cc_local_made_items_disc { get; set; }
       
        public decimal cc_special_import_items_disc { get; set; }
      
        public decimal cc_investment_items_disc { get; set; }
        
        public decimal cc_other_items_disc { get; set; }
       
        public decimal cc_g_p_doctor_max { get; set; }
   
        public int cc_disc_rule { get; set; }
        public string sec_insert_uid { get; set; }
        public Nullable<System.DateTime> sec_insert_date { get; set; }
        public string sec_update_uid { get; set; }
        public Nullable<System.DateTime> sec_update_date { get; set; }
        public decimal cc_pay_value { get; set; }
     
        public string pharm_id { get; set; }
    }
}
