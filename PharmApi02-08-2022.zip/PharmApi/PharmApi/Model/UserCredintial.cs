﻿using System.ComponentModel.DataAnnotations;

namespace PharmApi.Model
{
    public class UserCredintial
    {
        [Required]
        [EmailAddress]
        public string Email { get; set; }
        [Required]
        public string Password { get; set; }
    }
}
