﻿namespace PharmApi.Model
{
    public class meetupdataDTO: CreatemeetupdataDTO
    {
        public int id { get; set; }
    }

    
    public class CreatemeetupdataDTO
    {

        public string title { get; set; }
        public string Image { get; set; }
        public string address { get; set; }
        public string description { get; set; }
    }
}
