﻿using System.ComponentModel.DataAnnotations;
using System;
namespace PharmApi.Model
{
    public class return_trans_hDTO: Createreturn_trans_hDTO
    {
        public int id { get; set; }
    }
    public class Createreturn_trans_hDTO
    {
       
        public Nullable<int> mov_id { get; set; }
        public string Account_Entry { get; set; }
        public int pth_id { get; set; }
        public string sto_id { get; set; }
        public string ven_id { get; set; }
        public Nullable<decimal> no_of_items { get; set; }
        public Nullable<decimal> total_bill { get; set; }
        public Nullable<double> total_dis_per { get; set; }
        public Nullable<decimal> total_des_mon { get; set; }
        public Nullable<decimal> total_tax { get; set; }
        public Nullable<decimal> p_other_expenses { get; set; }
        public Nullable<decimal> pth_net_bill { get; set; }
        public string pth_notice { get; set; }
        public string ven_bill_no { get; set; }
        public Nullable<System.DateTime> ven_bill_date { get; set; }
        public Nullable<System.DateTime> pht_date { get; set; }
        public Nullable<int> pht_clint { get; set; }
        public Nullable<int> user_id_insert { get; set; }
        public Nullable<System.DateTime> insert_time { get; set; }
        public Nullable<int> user_id_update { get; set; }
        public Nullable<System.DateTime> update_time { get; set; }
        public Nullable<int> mov_stat { get; set; }
        public string mov_account { get; set; }
        public string mov_accountsec { get; set; }
        public Nullable<double> accountBalance { get; set; }
    }
}
