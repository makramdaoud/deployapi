﻿using System.ComponentModel.DataAnnotations;
using System;
namespace PharmApi.Model
{
    public class kitDTO: CreatekitDTO
    {
        public int id { get; set; }
    }
    public class CreatekitDTO
    {
     
        public string ItemMasterCode { get; set; }
        public Nullable<int> ItemMasterUnit { get; set; }
        public Nullable<double> ItemMasterqnty { get; set; }
        public string ItemChiledCode { get; set; }
        public Nullable<int> ItemChiledUnit { get; set; }
        public Nullable<double> Itemchiledqty { get; set; }
        public string user_insert { get; set; }
        public Nullable<System.DateTime> Insert_time { get; set; }
        public Nullable<System.DateTime> update_time { get; set; }
    }
}
