﻿using System.ComponentModel.DataAnnotations;
using System;
namespace PharmApi.Model
{
    public class PayableDTO: CreatePayableDTO
    {
        public int ReceiptNO { get; set; }
    }
    public class CreatePayableDTO
    {

        public Nullable<System.DateTime> ReceiptDate { get; set; }
        public string Chequeno { get; set; }
        public string Name { get; set; }
        public string BankCode { get; set; }
        public string AccountNOCode { get; set; }
        public Nullable<double> Value { get; set; }
        public string Currency { get; set; }
        public Nullable<System.DateTime> DueDate { get; set; }
        public string AmountString { get; set; }
        public string SignName { get; set; }
        public Nullable<bool> Collected { get; set; }
        public Nullable<System.DateTime> CollectedDate { get; set; }
        public string CollectedUser { get; set; }
        public Nullable<bool> Refused { get; set; }
        public Nullable<System.DateTime> RefusedDate { get; set; }
        public string RefusedUser { get; set; }
        public Nullable<bool> Cancel { get; set; }
        public Nullable<System.DateTime> CancelDate { get; set; }
        public string CancelUser { get; set; }
        public string Notes { get; set; }
        public string DebitCode { get; set; }
        public string Reason { get; set; }
        public Nullable<System.DateTime> ActionDate { get; set; }
        public string AddedUser { get; set; }
        public Nullable<System.DateTime> Dateupdate { get; set; }
        public string CostCenter { get; set; }
        public string CreditCode { get; set; }
    }
}
