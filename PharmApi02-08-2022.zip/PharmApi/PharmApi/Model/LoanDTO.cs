﻿using System.ComponentModel.DataAnnotations;
using System;
namespace PharmApi.Model
{
    public class LoanDTO: CreateLoanDTO
    {
        public int LoanID { get; set; }
    }
    public class CreateLoanDTO
    {
    
        public string Type { get; set; }
        public string Description { get; set; }
        public string BankName { get; set; }
        public string LoanName { get; set; }
        public Nullable<System.DateTime> StartingDate { get; set; }
        public Nullable<int> NoOfInstallment { get; set; }
        public Nullable<double> LoanPrincipal { get; set; }
        public Nullable<double> InstallmentAmount { get; set; }
        public string Costcenter { get; set; }
        public string AddedBy { get; set; }
        public Nullable<System.DateTime> DateUpdate { get; set; }
    }

}
