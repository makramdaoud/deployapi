﻿using System.ComponentModel.DataAnnotations;
using System;
namespace PharmApi.Model
{
    public class inventory_dDTO: Createinventory_dDTO
    {
        public int id { get; set; }
    }
    public class Createinventory_dDTO
    {
       
        public Nullable<int> mov_id { get; set; }
        public Nullable<int> fat_id { get; set; }
        public string itm_code { get; set; }
        public Nullable<System.DateTime> exp_date { get; set; }
        public Nullable<decimal> itm_sal_price { get; set; }
        public Nullable<decimal> itm_p_price { get; set; }
        public Nullable<decimal> itm_q { get; set; }
        public Nullable<decimal> itm_stock_qty { get; set; }
        public Nullable<decimal> itm_incres_qty { get; set; }
        public Nullable<decimal> item_short_qty { get; set; }
        public Nullable<int> unit_id { get; set; }
        public Nullable<double> std_itm_stock { get; set; }
    }
}
