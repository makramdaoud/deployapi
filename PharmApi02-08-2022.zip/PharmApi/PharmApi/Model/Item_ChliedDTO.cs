﻿namespace PharmApi.Model
{
    public class Item_ChliedDTO: CreateItem_ChliedDTO
    {
        public int id { get; set; }
    }
    public class CreateItem_ChliedDTO
    {

        public string Father_code { get; set; }
        public string Chiled_code { get; set; }
    }
}
