﻿
using System;
namespace PharmApi.Model
{
    public class CollectedVoucherDTO: CreateCollectedVoucherDTO
    {
        public int ReceiptNO { get; set; }

    }
    public class CreateCollectedVoucherDTO
    {
    
        public string RecRef { get; set; }
        public Nullable<System.DateTime> ReceiptDate { get; set; }
        public Nullable<int> SaveCode { get; set; }
        public Nullable<double> Amount { get; set; }
        public string Currency { get; set; }
        public Nullable<double> Rate { get; set; }
        public string Type { get; set; }
        public string VSource { get; set; }
        public string CollectedCode { get; set; }
        public string CollectedName { get; set; }
        public string Description { get; set; }
        public string AddedUser { get; set; }
        public Nullable<System.DateTime> AddedDate { get; set; }
        public Nullable<bool> Approved { get; set; }
        public string ChequeNO { get; set; }
        public Nullable<int> BankCode { get; set; }
        public Nullable<System.DateTime> DueDate { get; set; }
        public string AccountNO { get; set; }
        public string TotalString { get; set; }
        public Nullable<bool> Received { get; set; }
        public string CostCenter { get; set; }
    }
}
