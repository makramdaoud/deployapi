﻿using System.ComponentModel.DataAnnotations;
using System;
namespace PharmApi.Model
{
    public class sales_trans_dDTO: Createsales_trans_dDTO
    {
        public int id { get; set; }
    }
    public class Createsales_trans_dDTO
    {
        public decimal std_id { get; set; }
        public decimal sth_id { get; set; }
        public string itm_id { get; set; }
        public string c_id { get; set; }
        public Nullable<System.DateTime> exp_date { get; set; }
        public decimal qnty { get; set; }
        public Nullable<int> itm_unit { get; set; }
        public decimal itm_sell { get; set; }
        public Nullable<decimal> itm_cost { get; set; }
        public Nullable<decimal> itm_dis_mon { get; set; }
        public Nullable<double> itm_dis_per { get; set; }
        public Nullable<decimal> itm_back { get; set; }
        public Nullable<decimal> itm_back_price { get; set; }
        public Nullable<decimal> itm_aver_cost { get; set; }
        public string col1 { get; set; }
        public Nullable<decimal> col2 { get; set; }
        public Nullable<double> col3 { get; set; }
        public string sec_insert_uid { get; set; }
        public Nullable<System.DateTime> sec_insert_date { get; set; }
        public string sec_update_uid { get; set; }
        public Nullable<System.DateTime> sec_update_date { get; set; }
        public Nullable<int> itm_nexist { get; set; }
        public Nullable<int> std_itm_purchase_unit { get; set; }
        public Nullable<int> std_itm_unit1_unit2 { get; set; }
        public Nullable<int> std_itm_unit1_unit3 { get; set; }
        public Nullable<double> std_itm_stock { get; set; }
        public Nullable<int> std_r_itm_purchase_unit { get; set; }
        public Nullable<int> std_r_itm_unit1_unit2 { get; set; }
        public Nullable<int> std_r_itm_unit1_unit3 { get; set; }
        public Nullable<decimal> std_r_itm_stock { get; set; }
        public Nullable<int> std_itm_origin { get; set; }
        public Nullable<int> mov_id { get; set; }
      
        public Nullable<decimal> TAX_PER_PICES { get; set; }
        public Nullable<decimal> vatsales { get; set; }
        public Nullable<decimal> defrentvat { get; set; }
        public Nullable<decimal> CONTRACT_TOTALVAL { get; set; }
        public Nullable<decimal> CONTRACT_discontvalue { get; set; }
        public Nullable<decimal> CONTRACT_paied { get; set; }
        public Nullable<decimal> CONTRACT_Credit { get; set; }
        public Nullable<decimal> PURCH_PRICE { get; set; }
        public string PHARM_ID { get; set; }
        public Nullable<decimal> sales_net { get; set; }
        public Nullable<decimal> saleswithoutvit { get; set; }
        public decimal discount_per { get; set; }
        public decimal discount_val { get; set; }
    }
}
