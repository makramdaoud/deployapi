﻿using System.ComponentModel.DataAnnotations;
using System;
namespace PharmApi.Model
{
    public class DepositDTO: CreateDepositDTO
    {
        public int Deposit_id { get; set; }
    }
    public class CreateDepositDTO
    {
       
        public Nullable<System.DateTime> Deposit_Date { get; set; }
        public Nullable<decimal> Deposit_qty { get; set; }
        public Nullable<int> Deposit_Bank { get; set; }
        public string Deposit_Account_no { get; set; }
        public string Deposit_Slip_NO { get; set; }
        public string Deposit_Not { get; set; }
    }
}
