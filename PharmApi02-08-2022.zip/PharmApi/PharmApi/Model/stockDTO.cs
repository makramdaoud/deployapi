﻿using System.ComponentModel.DataAnnotations;
using System;
namespace PharmApi.Model
{
    public class stockDTO: CreatestockDTO
    {
        public int id { get; set; }
    }
    public class CreatestockDTO
    {
        
        public string item_id { get; set; }
        public Nullable<System.DateTime> exp_date { get; set; }
        public Nullable<decimal> qty { get; set; }
        public string stor_id { get; set; }
        public Nullable<decimal> pursh_price { get; set; }
        public Nullable<decimal> sales_price { get; set; }
        public Nullable<decimal> cost_price { get; set; }
        public Nullable<int> unit_id { get; set; }
    }
}
