﻿using System.ComponentModel.DataAnnotations;
using System;
namespace PharmApi.Model
{
    public class item_usage_mannerDTO: Createitem_usage_mannerDTO
    {
        public int ium_id { get; set; }
    }
    public class Createitem_usage_mannerDTO
    {
     
        public string ium_code { get; set; }
        public string ium_name_ar { get; set; }
        public string ium_name_en { get; set; }
        public string sec_insert_uid { get; set; }
        public Nullable<System.DateTime> sec_insert_date { get; set; }
        public string sec_update_uid { get; set; }
        public Nullable<System.DateTime> sec_update_date { get; set; }
    }
}
