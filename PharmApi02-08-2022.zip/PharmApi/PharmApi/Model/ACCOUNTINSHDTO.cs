﻿using System;

namespace PharmApi.Model
{
    public class ACCOUNTINSHDTO:CreateACCOUNTINSHDTO
    {
        public int ID { get; set; }
    }

    public class CreateACCOUNTINSHDTO
    {
     
        public string INTH_NAME { get; set; }
        public Nullable<int> INTH_USE { get; set; }
    }




}
