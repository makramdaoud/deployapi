﻿namespace PharmApi.Model
{
    public class Item_OriginsDTO: CreateItem_OriginsDTO
    {
        public short io_id { get; set; }
    }
    public class CreateItem_OriginsDTO
    {

        public string io_text_ar { get; set; }
    }
}
