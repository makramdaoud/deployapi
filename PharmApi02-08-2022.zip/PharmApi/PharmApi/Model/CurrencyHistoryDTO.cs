﻿using System.ComponentModel.DataAnnotations;
using System;
namespace PharmApi.Model
{
    public class CurrencyHistoryDTO: CreateCurrencyHistoryDTO
    {
        public int ID { get; set; }
    }
    public class CreateCurrencyHistoryDTO
    {
        
        public string Code { get; set; }
        public string Name { get; set; }
        public Nullable<double> Rate { get; set; }
        public string AddUser { get; set; }
        public Nullable<System.DateTime> DateUpdate { get; set; }
        public Nullable<int> Sort { get; set; }
        public Nullable<double> EGPRate { get; set; }
    }
}
