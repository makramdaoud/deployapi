﻿using System;
using System.ComponentModel.DataAnnotations;

namespace PharmApi.Model
{
    public class ACCLeadgerDTO: CreateACCLeadgerDTO
    {
        public int id { get; set; }
    }
        public class CreateACCLeadgerDTO
        {
        
            public int transno { get; set; }
            public string ACCcountCode { get; set; }
            public string AccountName { get; set; }
            public string ACCName { get; set; }
            public string ACCAName { get; set; }
            public Nullable<System.DateTime> TransDate { get; set; }
            public string TransType { get; set; }
            public string ReceiptNO { get; set; }
            public string Currancy { get; set; }
            public Nullable<double> Rate { get; set; }
            public Nullable<decimal> Amount { get; set; }
            public Nullable<decimal> Depit { get; set; }
            public Nullable<decimal> Credit { get; set; }
            public Nullable<decimal> Depit1 { get; set; }
            public Nullable<decimal> Credit1 { get; set; }
            public string Notes { get; set; }
            public Nullable<System.DateTime> DueDate { get; set; }
            public string REF { get; set; }

        }
    
}
