﻿using System.ComponentModel.DataAnnotations;
using System;
namespace PharmApi.Model
{
    public class FinancialStatementsDTO: CreateFinancialStatementsDTO
    {
        public int Code { get; set; }
    }
    public class CreateFinancialStatementsDTO
    {
    
        public string Name { get; set; }
        public string AddedBy { get; set; }
        public Nullable<System.DateTime> DateUpdate { get; set; }
    }
}
