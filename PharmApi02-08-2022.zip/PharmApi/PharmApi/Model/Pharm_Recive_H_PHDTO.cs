﻿using System.ComponentModel.DataAnnotations;
using System;
namespace PharmApi.Model
{
    public class Pharm_Recive_H_PHDTO: CreatePharm_Recive_H_PHDTO
    {
        public decimal ID { get; set; }
    }
    public class CreatePharm_Recive_H_PHDTO
    {
      
        public Nullable<int> MOV_ID { get; set; }
        public Nullable<int> MOV_FATH_ID { get; set; }
        public string MOV_STOR { get; set; }
        public string MOV_DIS { get; set; }
        public Nullable<decimal> MOV_TOTAL_QTY { get; set; }
        public Nullable<decimal> MOV_TOTAL_SALES_PRICE { get; set; }
        public Nullable<decimal> MOV_TOTAL_PURCH_PRICE { get; set; }
        public Nullable<decimal> MOV_TOTAL_COST_PRICE { get; set; }
        public Nullable<decimal> MOV_TOTAL_TAX_PRICE { get; set; }
        public Nullable<System.DateTime> MOV_DATE { get; set; }
        public string MOV_NOT { get; set; }
        public Nullable<double> MOV_FLAG { get; set; }
        public string MOV_ACCOUNT_DEPT1 { get; set; }
        public string MOV_ACCOUNT_DEPT2 { get; set; }
        public string MOV_ACCOUNT_DEPT3 { get; set; }
        public string MOV_ACCOUNT_DEPT4 { get; set; }
        public string MOV_ACCOUNT_CREDIT1 { get; set; }
        public string MOV_ACCOUNT_CREDIT2 { get; set; }
        public string MOV_ACCOUNT_CREDIT3 { get; set; }
        public string MOV_ACCOUNT_CREDIT4 { get; set; }
        public string insert_uid { get; set; }
        public Nullable<System.DateTime> insert_date { get; set; }
        public string update_uid { get; set; }
        public Nullable<System.DateTime> update_date { get; set; }
    }
}
