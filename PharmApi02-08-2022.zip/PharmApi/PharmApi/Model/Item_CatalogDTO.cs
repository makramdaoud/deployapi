﻿using System.ComponentModel.DataAnnotations;
using System;
namespace PharmApi.Model
{
    public class Item_CatalogDTO: CreateItem_CatalogDTO
    {
        public int ID { get; set; }
    }
    public class CreateItem_CatalogDTO
    {
        public decimal itm_id { get; set; }
        public string itm_code { get; set; }
        public string itm_code2 { get; set; }
        public string itm_int_code { get; set; }
        public string itm_usr_code { get; set; }
        public string itm_name_ar { get; set; }
        public string itm_name_en { get; set; }
        public Nullable<decimal> com_id { get; set; }
        public string itm_com_code { get; set; }
        public Nullable<int> itm_has_expire { get; set; }
        public Nullable<int> itm_ismedicine { get; set; }
        public Nullable<decimal> itm_location { get; set; }
        public Nullable<decimal> itm_request_limit { get; set; }
        public Nullable<decimal> itm_max_limit { get; set; }
        public Nullable<decimal> itm_min_limit { get; set; }
        public Nullable<decimal> itm_default_limit { get; set; }
        public Nullable<decimal> itm_purchase_unit { get; set; }
        public Nullable<decimal> itm_sell_unit { get; set; }
        public Nullable<decimal> itm_def_sell_price { get; set; }
        public Nullable<decimal> itm_def_tax { get; set; }
        public Nullable<decimal> itm_def_pharm_price { get; set; }
        public string itm_active { get; set; }
        public Nullable<decimal> itm_unit1 { get; set; }
        public Nullable<decimal> itm_unit2 { get; set; }
        public Nullable<decimal> itm_unit3 { get; set; }
        public Nullable<decimal> itm_unit1_unit2 { get; set; }
        public Nullable<decimal> itm_unit1_unit3 { get; set; }
        public Nullable<int> itm_freez { get; set; }
        public string itm_scientific_n1 { get; set; }
        public string itm_scientific_n2 { get; set; }
        public Nullable<decimal> itm_g1 { get; set; }
        public Nullable<decimal> itm_g2 { get; set; }
        public Nullable<decimal> itm_g3 { get; set; }
        public Nullable<decimal> itm_scientific_group_id { get; set; }
        public Nullable<decimal> itm_usage_manner_id { get; set; }
        public string itm_effictive { get; set; }
        public string itm_effictive_perc { get; set; }
        public Nullable<int> itm_isprev { get; set; }
        public Nullable<decimal> itm_itf_id { get; set; }
        public Nullable<int> itm_stop_sell { get; set; }
        public Nullable<int> itm_stop_pur { get; set; }
        public Nullable<int> itm_print_barcode { get; set; }
        public Nullable<int> itm_allow_discount { get; set; }
        public Nullable<double> itm_max_disc_per { get; set; }
        public Nullable<double> itm_max_disc_val { get; set; }
        public Nullable<int> itm_print_name { get; set; }
        public Nullable<int> itm_sales_avreage_period { get; set; }
        public Nullable<int> itm_purchase_avreage_period { get; set; }
        public Nullable<int> itm_srvc { get; set; }
        public Nullable<int> itm_origin { get; set; }
        public Nullable<int> itm_isShortage { get; set; }
        public Nullable<decimal> itm_mid_unit_dif { get; set; }
        public Nullable<decimal> itm_small_unit_dif { get; set; }
        public string sec_insert_uid { get; set; }
        public Nullable<System.DateTime> sec_insert_date { get; set; }
        public string sec_update_uid { get; set; }
        public Nullable<System.DateTime> sec_update_date { get; set; }
        public Nullable<int> itm_frac_qty { get; set; }
        public Nullable<int> itm_favourite { get; set; }
        public string ucp_code { get; set; }
        public string itm_notes { get; set; }
        public Nullable<decimal> itm_sales_disc { get; set; }
        public Nullable<int> itm_nopurreturn { get; set; }
        public Nullable<int> itm_price_updated { get; set; }
        public Nullable<int> itm_sell_nostock { get; set; }
       
        public Nullable<int> itm_G_id { get; set; }
    }
}
