﻿using System.ComponentModel.DataAnnotations;
using System;
namespace PharmApi.Model
{
    public class Item_ObjectsDTO: CreateItem_ObjectsDTO
    {
        public int io_id { get; set; }
    }

    public class CreateItem_ObjectsDTO
    {

      
        public decimal io_itm_id { get; set; }
        public string io_itm_int { get; set; }
        public string sec_insert_uid { get; set; }
        public Nullable<System.DateTime> sec_insert_date { get; set; }
        public string sec_update_uid { get; set; }
        public Nullable<System.DateTime> sec_update_date { get; set; }
    }
}
