﻿using System.ComponentModel.DataAnnotations;
using System;
namespace PharmApi.Model
{
    public class infoDTO: CreateinfoDTO
    {
        public int id { get; set; }
    }
    public class CreateinfoDTO
    {
    
        public string Employ_Name { get; set; }
        public Nullable<int> Employ_michin_code { get; set; }
        public string Employ_pharm { get; set; }
        public Nullable<decimal> Employ_hour_salary { get; set; }
        public Nullable<System.TimeSpan> Employ_frist_time { get; set; }
        public Nullable<System.TimeSpan> Employ_out_time { get; set; }
        public Nullable<int> Employ_jop { get; set; }
        public string pharm_code { get; set; }
        public Nullable<int> activemp { get; set; }
        public string pharm_insh { get; set; }
    }
}
