﻿using System;

namespace PharmApi.Model
{
    public class AccountsChartDTO:CreateAccountsChartDTO
    {
        //public string ACCCode { get; set; }
    }
    public class CreateAccountsChartDTO
    {
        public string ACCCode { get; set; }
        public string PARENTCode { get; set; }
        public string ACCName { get; set; }
        public string ACCAName { get; set; }
        public string Currency { get; set; }
        public Nullable<bool> ACCKind { get; set; }
        public Nullable<bool> Receipt { get; set; }
        public Nullable<bool> Payment { get; set; }
    }
}
