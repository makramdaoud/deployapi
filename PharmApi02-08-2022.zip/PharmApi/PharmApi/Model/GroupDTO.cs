﻿using System.ComponentModel.DataAnnotations;
using System;
namespace PharmApi.Model
{
    public class GroupDTO: CreateGroupDTO
    {
        public int g_id { get; set; }
    }
    public class CreateGroupDTO
    {
  
        public string g_name_ar { get; set; }
        public string g_name_en { get; set; }
        public Nullable<int> g_parent { get; set; }
        public string sec_insert_uid { get; set; }
        public Nullable<System.DateTime> sec_insert_date { get; set; }
        public string sec_update_uid { get; set; }
        public Nullable<System.DateTime> sec_update_date { get; set; }
    }
}
