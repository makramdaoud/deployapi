﻿using System.ComponentModel.DataAnnotations;
using System;
namespace PharmApi.Model
{
    public class GeneralLedgerDTO: CreateGeneralLedgerDTO
    {
        public int TransNO { get; set; }
    }
    public class CreateGeneralLedgerDTO
    {
  
        public Nullable<System.DateTime> TransDate { get; set; }
        public string TransType { get; set; }
        public Nullable<int> ACCOrder { get; set; }
        public Nullable<int> TreasuryCode { get; set; }
        public Nullable<int> ReceiptNO { get; set; }
        public string ACCcountCode { get; set; }
        public string Description { get; set; }
        public string Currancy { get; set; }
        public Nullable<double> Rate { get; set; }
        public string BankAccount { get; set; }
        public string ChequeNO { get; set; }
        public Nullable<double> Amount { get; set; }
        public Nullable<double> Depit { get; set; }
        public Nullable<double> Credit { get; set; }
        public Nullable<double> Depit1 { get; set; }
        public Nullable<double> Credit1 { get; set; }
        public string Notes { get; set; }
        public string VNote { get; set; }
        public Nullable<bool> Posting { get; set; }
        public Nullable<System.DateTime> PostingDate { get; set; }
        public string AddedBy { get; set; }
        public Nullable<System.DateTime> AddedDate { get; set; }
        public string UpdatedBy { get; set; }
        public Nullable<System.DateTime> UpdatedDate { get; set; }
        public Nullable<System.DateTime> DueDate { get; set; }
        public string REF { get; set; }
        public string CostCenter { get; set; }
    }
}
