﻿namespace PharmApi.Model
{
    public class PharmcodeDTO: CreatePharmcodeDTO
    {
        public string PharmCode { get; set; }
    }
    public class CreatePharmcodeDTO
    {
 
        public string pharmname { get; set; }
    }
}
