﻿namespace PharmApi.Model
{
    public class ActionsCodeDTO: CreateActionsCodeDTO
    {
        public int id { get; set; }
    }
    public class CreateActionsCodeDTO
    {
     
        public string ActionName { get; set; }
        public string AccCode { get; set; }
    }
}
