﻿using System;
namespace PharmApi.Model
{
    public class CompanyDTO: CreateCompanyDTO
    {
        public decimal com_id { get; set; }
    }
    public class CreateCompanyDTO
    {
       
        public string com_code { get; set; }
        public string com_name_ar { get; set; }
        public string com_name_en { get; set; }
        public string com_tel { get; set; }
        public string com_address { get; set; }
        public string com_usr_code { get; set; }
        public string com_active { get; set; }
        public string sec_insert_uid { get; set; }
        public Nullable<System.DateTime> sec_insert_date { get; set; }
        public string sec_update_uid { get; set; }
        public Nullable<System.DateTime> sec_update_date { get; set; }
    }
}
