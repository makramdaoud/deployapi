﻿using System.ComponentModel.DataAnnotations;
using System;
namespace PharmApi.Model
{
    public class CustomerDTO: CreateCustomerDTO
    {
        public int id { get; set; }
    }
    public class CreateCustomerDTO
    {
        public decimal cust_id { get; set; }
        public string cust_code { get; set; }
        public string cust_name_ar { get; set; }
        public string cust_name_en { get; set; }
        public Nullable<System.DateTime> cust_birth_date { get; set; }
        public string cust_gender { get; set; }
        public string cust_job { get; set; }
        public string cust_mobile { get; set; }
        public string cust_tel { get; set; }
        public string cust_address { get; set; }
        public Nullable<decimal> cust_type { get; set; }
        public Nullable<decimal> cust_parent { get; set; }
        public string cust_active { get; set; }
        public Nullable<System.DateTime> cust_active_date { get; set; }
        public Nullable<System.DateTime> cust_stop_date { get; set; }
        public Nullable<decimal> cust_max_credit { get; set; }
        public Nullable<decimal> cust_current_credit { get; set; }
        public Nullable<double> cust_pay_perc { get; set; }
        public Nullable<decimal> cust_discount_level { get; set; }
        public Nullable<decimal> cust_discount_value { get; set; }
        public Nullable<double> cust_discount_perc { get; set; }
        public string cust_sell_cost { get; set; }
        public Nullable<double> cust_profit_perc { get; set; }
        public string cust_parent_items { get; set; }
        public string cust_parent_groups { get; set; }
        public string cust_parent_rules { get; set; }
        public string cust_car_number { get; set; }
        public Nullable<int> cust_payment { get; set; }
        public string cust_ph_owner_name { get; set; }
        public Nullable<decimal> cust_contract_id { get; set; }
        public Nullable<decimal> cust_p_branch_id { get; set; }
        public string cust_med_insurance { get; set; }
        public Nullable<decimal> cust_extra_disc { get; set; }
        public string sec_insert_uid { get; set; }
        public Nullable<System.DateTime> sec_insert_date { get; set; }
        public string sec_update_uid { get; set; }
        public Nullable<System.DateTime> sec_update_date { get; set; }
        public Nullable<int> cust_rec_name { get; set; }
        public Nullable<decimal> c_local_items_disc { get; set; }
        public Nullable<decimal> c_imported_items_disc { get; set; }
        public Nullable<decimal> c_local_made_items_disc { get; set; }
        public Nullable<decimal> c_special_import_items_disc { get; set; }
        public Nullable<decimal> c_investment_items_disc { get; set; }
        public Nullable<decimal> c_other_items_disc { get; set; }
        public Nullable<decimal> cust_start_credit { get; set; }
        public Nullable<decimal> cust_start_debit { get; set; }
        public Nullable<decimal> pont2mony { get; set; }
        public Nullable<decimal> cust_curr_points { get; set; }
        public Nullable<decimal> cust_def_sell_store { get; set; }
        public string cust_notes { get; set; }
        public Nullable<int> cust_region_id { get; set; }
        public Nullable<int> cust_prevent_credit { get; set; }
      
        public string pharm_code { get; set; }
        public string cust_contractcompany { get; set; }
        public string cust_contractcompanydiscount { get; set; }
    }
}
