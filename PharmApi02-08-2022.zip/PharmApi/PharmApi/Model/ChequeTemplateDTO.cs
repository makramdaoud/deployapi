﻿namespace PharmApi.Model
{
    public class ChequeTemplateDTO: CreateChequeTemplateDTO
    {
        public int  id { get; set; }
    }
    public class CreateChequeTemplateDTO
    {
        public string BankCode { get; set; }
        public string Template { get; set; }
        public string CreditCode { get; set; }
    }
}
