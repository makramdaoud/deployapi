﻿namespace PharmApi.Model
{
    public class Item_Origins_لإ_
    {
    }
}
