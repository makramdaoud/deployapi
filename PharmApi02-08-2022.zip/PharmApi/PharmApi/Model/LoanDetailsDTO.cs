﻿using System.ComponentModel.DataAnnotations;
using System;
namespace PharmApi.Model
{
    public class LoanDetailsDTO: CreateLoanDetailsDTO
    {
        public int LoanID { get; set; }
    }
    public class CreateLoanDetailsDTO
    {
        
        public int installmentNO { get; set; }
        public Nullable<System.DateTime> InstallmentDate { get; set; }
        public Nullable<double> Amount { get; set; }
        public Nullable<bool> paid { get; set; }
        public Nullable<int> paymentNo { get; set; }
    }
}
