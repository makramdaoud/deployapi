﻿namespace PharmApi.Model
{
    public class ITEMSELECTEDDTO: CreateITEMSELECTEDDTO
    {
        public int ID { get; set; }
    }
    public class CreateITEMSELECTEDDTO
    {
        
        public string ITM_CODE { get; set; }
        public string ITM_AR_NAME { get; set; }
        public string ITM_USER { get; set; }
    }
}
