﻿using System.ComponentModel.DataAnnotations;
using System;
namespace PharmApi.Model
{
    public class kpitableDTO: CreatekpitableDTO
    {
        public int id { get; set; }
    }
    public class CreatekpitableDTO
    {
        
        public string pharm_id { get; set; }
        public Nullable<int> mov_id { get; set; }
        public Nullable<System.DateTime> dat { get; set; }
        public string pharmname { get; set; }
        public decimal Total_cash { get; set; }
        public decimal Total_post { get; set; }
        public decimal Total_visa { get; set; }
        public decimal Total_delevery { get; set; }
        public decimal Total_Contract { get; set; }
        public decimal Total_Medicin { get; set; }
        public Nullable<decimal> Total_DADY { get; set; }
        public decimal Total_Non_medicin { get; set; }
        public decimal returnsales { get; set; }
        public decimal Total_Not { get; set; }
        public decimal avt { get; set; }
        public decimal Noi { get; set; }
        public decimal del_NoT { get; set; }
        public decimal avdeltrans { get; set; }
    }
}
