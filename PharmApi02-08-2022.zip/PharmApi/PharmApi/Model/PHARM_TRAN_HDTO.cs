﻿using System.ComponentModel.DataAnnotations;
using System;
namespace PharmApi.Model
{
    public class PHARM_TRAN_HDTO: CreatePHARM_TRAN_HDTO
    {
        public int id { get; set; }
    }
    public class CreatePHARM_TRAN_HDTO
    {
      
        public string TRA_PH_SOURC_ID { get; set; }
        public string TRA_PH_DES_ID { get; set; }
        public string TRA_PH_SOURC_STOR { get; set; }
        public string TRA_PH_DES_STOR { get; set; }
        public Nullable<System.DateTime> TRA_DATE { get; set; }
        public Nullable<double> TRA_TOTALQ { get; set; }
        public Nullable<double> TRA_TOTALP { get; set; }
        public string TRA_USER_ID { get; set; }
        public Nullable<System.DateTime> TRA_INSERT_DATE { get; set; }
        public string TRA_UPDATE_USER { get; set; }
        public Nullable<System.DateTime> TRA_UPDATE_DATETIME { get; set; }
        public string TRA_DEPT { get; set; }
        public string TRA_CREDIT { get; set; }
        public Nullable<int> TRA_FLAG { get; set; }
        public Nullable<int> SEIAL { get; set; }
        public string delver_id { get; set; }
        public string note { get; set; }
    }
}
