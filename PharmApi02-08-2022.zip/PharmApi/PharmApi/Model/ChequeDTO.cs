﻿using System;

namespace PharmApi.Model
{
    public class ChequeDTO: CreateChequeDTO
    {
        public int id { get; set; }
    }
    public class CreateChequeDTO
    {
       
        public int ReceiptNO { get; set; }
        public string ChequeNO { get; set; }
        public string BankName { get; set; }
        public Nullable<System.DateTime> DueDate { get; set; }
        public string Currancy { get; set; }
        public Nullable<double> Rate { get; set; }
        public Nullable<double> Value { get; set; }
        public string AddedUser { get; set; }
        public Nullable<System.DateTime> DateUpdate { get; set; }
        public Nullable<bool> Back { get; set; }
        public string returnBy { get; set; }
        public Nullable<System.DateTime> ReturnDate { get; set; }
        public Nullable<bool> InTreasury { get; set; }
        public Nullable<System.DateTime> TreasuryDate { get; set; }
        public Nullable<bool> INBank { get; set; }
        public string BankCode { get; set; }
        public Nullable<System.DateTime> BankDate { get; set; }
        public Nullable<bool> Collected { get; set; }
        public Nullable<System.DateTime> CollectedDate { get; set; }
        public string AccountNO { get; set; }
        public Nullable<bool> Refuesd { get; set; }
        public Nullable<System.DateTime> RefuesdDate { get; set; }
        public string Collector { get; set; }
        public Nullable<double> BankCharge { get; set; }
        public byte Ordering { get; set; }
        public string Type { get; set; }
        public Nullable<bool> Active { get; set; }
        public Nullable<System.DateTime> ActiveDate { get; set; }
        public string PrintName { get; set; }
    }
}
