﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PharmApi.Data
{
    public class accountshortcutstor
    {
        public int id { get; set; }
        public string pharm_code { get; set; }
        public string pharmname { get; set; }
        public string StoreId { get; set; }
        public string Stor_Name { get; set; }
    }
}
