﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace PharmApi.Data
{
    public class Pharmcode
    {
        [Key]
        public string PharmCode { get; set; }
        public string pharmname { get; set; }
    }
}
