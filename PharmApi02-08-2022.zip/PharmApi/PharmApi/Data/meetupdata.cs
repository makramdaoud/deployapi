﻿namespace PharmApi.Data
{
    public class meetupdata
    {
        public int id { get; set; }
        public string title { get; set; }
        public string Image { get; set; }
        public string address { get; set; }
        public string description { get; set; }
    }
}
