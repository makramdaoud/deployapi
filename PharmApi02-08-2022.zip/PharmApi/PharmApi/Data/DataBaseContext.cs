﻿

using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using PharmApi.Configrations.Entity;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;

namespace PharmApi.Data
{
    public class DataBaseContext : IdentityDbContext
    {
        public DataBaseContext(DbContextOptions options) : base(options)
        {

        }


        public Microsoft.EntityFrameworkCore.DbSet<meetupdata> meetupdata { get; set; }
        public Microsoft.EntityFrameworkCore.DbSet<Pharmcode> Pharmcode { get; set; }
        public Microsoft.EntityFrameworkCore.DbSet<Loan> Loan { get; set; }
        public Microsoft.EntityFrameworkCore.DbSet<CurrencyHistory> CurrencyHistory { get; set; }
        public Microsoft.EntityFrameworkCore.DbSet<CollectedVoucher> CollectedVoucher { get; set; }
        public Microsoft.EntityFrameworkCore.DbSet<ChequeTemplate> ChequeTemplate { get; set; }
        public Microsoft.EntityFrameworkCore.DbSet<ActionsCode> ActionsCode { get; set; }
        public Microsoft.EntityFrameworkCore.DbSet<AccountsChart> AccountsChart { get; set; }
        public Microsoft.EntityFrameworkCore.DbSet<accountshortcutstor> accountshortcutstor { get; set; }
        public Microsoft.EntityFrameworkCore.DbSet<ACCLeadger> ACCLeadger { get; set; }
        public Microsoft.EntityFrameworkCore.DbSet<ACCOUNTINSH> ACCOUNTINSHS { get; set; }
        public Microsoft.EntityFrameworkCore.DbSet<Cheque> Cheque { get; set; }
        public Microsoft.EntityFrameworkCore.DbSet<Company> Company { get; set; }
        public Microsoft.EntityFrameworkCore.DbSet<Coupon> Coupon { get; set; }
        public Microsoft.EntityFrameworkCore.DbSet<Currency> Currency { get; set; }
        public Microsoft.EntityFrameworkCore.DbSet<Customer> Customer { get; set; }
        public Microsoft.EntityFrameworkCore.DbSet<Customer_branches> Customer_branches { get; set; }
        public Microsoft.EntityFrameworkCore.DbSet<Customer_Contracts> Customer_Contracts { get; set; }
        public Microsoft.EntityFrameworkCore.DbSet<customer_credit_chng> customer_credit_chng { get; set; }
        public Microsoft.EntityFrameworkCore.DbSet<Customer_Delivery> Customer_Delivery { get; set; }
        public Microsoft.EntityFrameworkCore.DbSet<Customer_Groups> Customer_Groups { get; set; }
        public Microsoft.EntityFrameworkCore.DbSet<Customer_Items> Customer_Items { get; set; }
        public Microsoft.EntityFrameworkCore.DbSet<Customer_Points_Calc> Customer_Points_Calc { get; set; }
        public Microsoft.EntityFrameworkCore.DbSet<Customer_Rules> Customer_Rules { get; set; }
        public Microsoft.EntityFrameworkCore.DbSet<Customer_Type> Customer_Type { get; set; }
        public Microsoft.EntityFrameworkCore.DbSet<Customer_Visa> Customer_Visa { get; set; }
        public Microsoft.EntityFrameworkCore.DbSet<deleveryinformation> deleveryinformation { get; set; }
        public Microsoft.EntityFrameworkCore.DbSet<Deposit> Deposit { get; set; }
        public Microsoft.EntityFrameworkCore.DbSet<Deposit_Bank> Deposit_Bank { get; set; }
        public Microsoft.EntityFrameworkCore.DbSet<Education> Education { get; set; }
        public Microsoft.EntityFrameworkCore.DbSet<Employ> Employ { get; set; }
        public Microsoft.EntityFrameworkCore.DbSet<Employ_ledger> Employ_ledger { get; set; }
        public Microsoft.EntityFrameworkCore.DbSet<employhistory> employhistory { get; set; }
        public Microsoft.EntityFrameworkCore.DbSet<Group> Group { get; set; }
        public Microsoft.EntityFrameworkCore.DbSet<inersales_trans_d> inersales_trans_d { get; set; }
        public Microsoft.EntityFrameworkCore.DbSet<inersales_trans_h> inersales_trans_h { get; set; }
        public Microsoft.EntityFrameworkCore.DbSet<info> info { get; set; }
        public Microsoft.EntityFrameworkCore.DbSet<InterCode> InterCode { get; set; }
        public Microsoft.EntityFrameworkCore.DbSet<inventory_d> inventory_d { get; set; }
        public Microsoft.EntityFrameworkCore.DbSet<inventory_h> inventory_h { get; set; }
        public Microsoft.EntityFrameworkCore.DbSet<Item_Catalog> Item_Catalog { get; set; }
        public Microsoft.EntityFrameworkCore.DbSet<Item_Chlied> Item_Chlied { get; set; }
        public Microsoft.EntityFrameworkCore.DbSet<Item_Objects> Item_Objects { get; set; }
        public Microsoft.EntityFrameworkCore.DbSet<Item_Origins> Item_Origins { get; set; }
        public Microsoft.EntityFrameworkCore.DbSet<item_usage_manner> item_usage_manner { get; set; }
        public Microsoft.EntityFrameworkCore.DbSet<ITEMSELECTED> ITEMSELECTED { get; set; }
        public Microsoft.EntityFrameworkCore.DbSet<kit> kit { get; set; }
        public Microsoft.EntityFrameworkCore.DbSet<kpitable> kpitable { get; set; }
        public Microsoft.EntityFrameworkCore.DbSet<PaymentVoucher> PaymentVoucher { get; set; }
        public Microsoft.EntityFrameworkCore.DbSet<Payable> Payable { get; set; }
        public Microsoft.EntityFrameworkCore.DbSet<LoanDetails> LoanDetails { get; set; }

        public Microsoft.EntityFrameworkCore.DbSet<GeneralLedger> GeneralLedger { get; set; }
        public Microsoft.EntityFrameworkCore.DbSet<FSDetails> FSDetails { get; set; }
        public Microsoft.EntityFrameworkCore.DbSet<FinancialStatements> FinancialStatements { get; set; }
        public Microsoft.EntityFrameworkCore.DbSet<pur_trans_d> pur_trans_d { get; set; }
        public Microsoft.EntityFrameworkCore.DbSet<pur_trans_h> pur_trans_h { get; set; }
        public Microsoft.EntityFrameworkCore.DbSet<return_trans_d> return_trans_d { get; set; }
        public Microsoft.EntityFrameworkCore.DbSet<return_trans_h> return_trans_h { get; set; }
        public Microsoft.EntityFrameworkCore.DbSet<sales_trans_d> sales_trans_d { get; set; }
        public Microsoft.EntityFrameworkCore.DbSet<sales_trans_h> sales_trans_h { get; set; }
        public Microsoft.EntityFrameworkCore.DbSet<stock> stock { get; set; }
        public Microsoft.EntityFrameworkCore.DbSet<PHARM_TRAN_H> PHARM_TRAN_H { get; set; }
        public Microsoft.EntityFrameworkCore.DbSet<PHARM_TRAN_D> PHARM_TRAN_D { get; set; }
        public Microsoft.EntityFrameworkCore.DbSet<Pharm_Recive_H_PH> Pharm_Recive_H_PH { get; set; }
        public Microsoft.EntityFrameworkCore.DbSet<Pharm_Recive_D_PH> Pharm_Recive_D_PH { get; set; }


        protected virtual void onOnModelCreating(ModelBuilder builder)
        {

            base.OnModelCreating(builder);
            builder.ApplyConfiguration(new RoleConfigrations());
            //     builder.Entity<Currency>()
            //.Property(p => p.Code)
            //.ValueGeneratedOnAdd();

        }




    }
}
