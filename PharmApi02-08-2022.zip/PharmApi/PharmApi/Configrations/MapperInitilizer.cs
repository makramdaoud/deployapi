﻿using AutoMapper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using PharmApi.Data;
using PharmApi.Model;

namespace PharmApi.Configrations
{
    public class MapperInitilizer : Profile
    {
        public MapperInitilizer()
        {
            CreateMap<meetupdata, meetupdataDTO>().ReverseMap();
            CreateMap<meetupdata, CreatemeetupdataDTO>().ReverseMap();
            CreateMap<accountshortcutstor, accountshortcutstorDTO>().ReverseMap();
            CreateMap<accountshortcutstor, CreateaccountshortcutstorDTO>().ReverseMap();
            CreateMap<APIUser, UserDTO>().ReverseMap();


            CreateMap<ACCLeadger, ACCLeadgerDTO>().ReverseMap();
            CreateMap<ACCLeadger, CreateACCLeadgerDTO>().ReverseMap();


            CreateMap<ACCOUNTINSH, ACCOUNTINSHDTO>().ReverseMap();
            CreateMap<ACCOUNTINSH, CreateACCOUNTINSHDTO>().ReverseMap();

            CreateMap<AccountsChart, AccountsChartDTO>().ReverseMap();
            CreateMap<AccountsChart, CreateAccountsChartDTO>().ReverseMap();

            CreateMap<ActionsCode, ActionsCodeDTO>().ReverseMap();
            CreateMap<ActionsCode, CreateActionsCodeDTO>().ReverseMap();

            CreateMap<Cheque, ChequeDTO>().ReverseMap();
            CreateMap<Cheque, CreateChequeDTO>().ReverseMap();

            CreateMap<ChequeTemplate, ChequeTemplateDTO>().ReverseMap();
            CreateMap<ChequeTemplate, CreateChequeTemplateDTO>().ReverseMap();

            CreateMap<CollectedVoucher, CollectedVoucherDTO>().ReverseMap();
            CreateMap<CollectedVoucher, CreateCollectedVoucherDTO>().ReverseMap();


            CreateMap<Company, CompanyDTO>().ReverseMap();
            CreateMap<Company, CreateCompanyDTO>().ReverseMap();

            CreateMap<Coupon, CouponDTO>().ReverseMap();
            CreateMap<Coupon, CreateCouponDTO>().ReverseMap();

            CreateMap<Currency, CurrencyDTO>().ReverseMap();
            CreateMap<Currency, CreateCurrencyDTO>().ReverseMap();

            CreateMap<CurrencyHistory, CurrencyHistoryDTO>().ReverseMap();
            CreateMap<CurrencyHistory, CreateCurrencyHistoryDTO>().ReverseMap();

            CreateMap<Customer_branches, Customer_branchesDTO>().ReverseMap();
            CreateMap<Customer_branches, CreateCustomer_branchesDTO>().ReverseMap();


            CreateMap<Customer_Contracts, Customer_ContractsDTO>().ReverseMap();
            CreateMap<Customer_Contracts, CreateCustomer_ContractsDTO>().ReverseMap();

            CreateMap<Customer, CustomerDTO>().ReverseMap();
            CreateMap<Customer, CreateCustomerDTO>().ReverseMap();

            CreateMap<Deposit, DepositDTO>().ReverseMap();
            CreateMap<Deposit, CreateDepositDTO>().ReverseMap();

            CreateMap<FinancialStatements, FinancialStatementsDTO>().ReverseMap();
            CreateMap<FinancialStatements, CreateFinancialStatementsDTO>().ReverseMap();

            CreateMap<GeneralLedger, GeneralLedgerDTO>().ReverseMap();
            CreateMap<GeneralLedger, CreateGeneralLedgerDTO>().ReverseMap();


            CreateMap<Group, GroupDTO>().ReverseMap();
            CreateMap<Group, CreateGroupDTO>().ReverseMap();

            CreateMap<inersales_trans_d, inersales_trans_dDTO>().ReverseMap();
            CreateMap<inersales_trans_d, Createinersales_trans_dDTO>().ReverseMap();


            CreateMap<inersales_trans_h, inersales_trans_hDTO>().ReverseMap();
            CreateMap<inersales_trans_h, Createinersales_trans_hDTO>().ReverseMap();


            CreateMap<info, infoDTO>().ReverseMap();
            CreateMap<info, CreateinfoDTO>().ReverseMap();


            CreateMap<InterCode, InterCodeDTO>().ReverseMap();
            CreateMap<InterCode, CreateInterCodeDTO>().ReverseMap();


            CreateMap<inventory_d, inventory_dDTO>().ReverseMap();
            CreateMap<inventory_d, Createinventory_dDTO>().ReverseMap();



            CreateMap<inventory_h, inventory_hDTO>().ReverseMap();
            CreateMap<inventory_h, Createinventory_hDTO>().ReverseMap();


            CreateMap<Item_Catalog, Item_CatalogDTO>().ReverseMap();
            CreateMap<Item_Catalog, CreateItem_CatalogDTO>().ReverseMap();


            CreateMap<Item_Chlied, Item_ChliedDTO>().ReverseMap();
            CreateMap<Item_Chlied, CreateItem_ChliedDTO>().ReverseMap();


            CreateMap<Item_Objects, Item_ObjectsDTO>().ReverseMap();
            CreateMap<Item_Objects, CreateItem_ObjectsDTO>().ReverseMap();


            CreateMap<Item_Origins, Item_OriginsDTO>().ReverseMap();
            CreateMap<Item_Origins, CreateItem_OriginsDTO>().ReverseMap();


            CreateMap<item_usage_manner, item_usage_mannerDTO>().ReverseMap();
            CreateMap<item_usage_manner, Createitem_usage_mannerDTO>().ReverseMap();


            CreateMap<ITEMSELECTED, ITEMSELECTEDDTO>().ReverseMap();
            CreateMap<ITEMSELECTED, CreateITEMSELECTEDDTO>().ReverseMap();

            CreateMap<kit, kitDTO>().ReverseMap();
            CreateMap<kit, CreatekitDTO>().ReverseMap();

            CreateMap<kpitable, kpitableDTO>().ReverseMap();
            CreateMap<kpitable, CreatekpitableDTO>().ReverseMap();


            CreateMap<LoanDetails, LoanDetailsDTO>().ReverseMap();
            CreateMap<LoanDetails, CreateLoanDetailsDTO>().ReverseMap();

            CreateMap<Loan, LoanDTO>().ReverseMap();
            CreateMap<Loan, CreateLoanDTO>().ReverseMap();

            CreateMap<Payable, PayableDTO>().ReverseMap();
            CreateMap<Payable, CreatePayableDTO>().ReverseMap();

            CreateMap<PaymentVoucher, PaymentVoucherDTO>().ReverseMap();
            CreateMap<PaymentVoucher, CreatePaymentVoucherDTO>().ReverseMap();

            CreateMap<Pharm_Recive_D_PH, Pharm_Recive_D_PHDTO>().ReverseMap();
            CreateMap<Pharm_Recive_D_PH, CreatePharm_Recive_D_PHDTO>().ReverseMap();


            CreateMap<Pharm_Recive_H_PH, Pharm_Recive_H_PHDTO>().ReverseMap();
            CreateMap<Pharm_Recive_H_PH, CreatePharm_Recive_H_PHDTO>().ReverseMap();

            CreateMap<PHARM_TRAN_D, PHARM_TRAN_DDTO>().ReverseMap();
            CreateMap<PHARM_TRAN_D, CreatePHARM_TRAN_DDTO>().ReverseMap();

            CreateMap<PHARM_TRAN_H, PHARM_TRAN_HDTO>().ReverseMap();
            CreateMap<PHARM_TRAN_H, CreatePHARM_TRAN_HDTO>().ReverseMap();



            CreateMap<Pharmcode, PharmcodeDTO>().ReverseMap();
            CreateMap<Pharmcode, CreatePharmcodeDTO>().ReverseMap();


            CreateMap<pur_trans_d, pur_trans_dDTO>().ReverseMap();
            CreateMap<pur_trans_d, Createpur_trans_dDTO>().ReverseMap();

            CreateMap<pur_trans_h, pur_trans_hDTO>().ReverseMap();
            CreateMap<pur_trans_h, Createpur_trans_hDTO>().ReverseMap();

            CreateMap<return_trans_d, return_trans_dDTO>().ReverseMap();
            CreateMap<return_trans_d, Createreturn_trans_dDTO>().ReverseMap();


            CreateMap<return_trans_h, return_trans_hDTO>().ReverseMap();
            CreateMap<return_trans_h, Createreturn_trans_hDTO>().ReverseMap();


            CreateMap<sales_trans_d, sales_trans_dDTO>().ReverseMap();
            CreateMap<sales_trans_d, Createsales_trans_dDTO>().ReverseMap();



            CreateMap<sales_trans_h, sales_trans_hDTO>().ReverseMap();
            CreateMap<sales_trans_h, Createsales_trans_hDTO>().ReverseMap();




            CreateMap<stock, stockDTO>().ReverseMap();
            CreateMap<stock, CreatestockDTO>().ReverseMap();



        }
    }
}
