using AutoMapper;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using PharmApi.Configrations;
using PharmApi.Data;
using PharmApi.IRepository;
using PharmApi.Repository;
using PharmApi.Services;
using System.Text;

var builder = WebApplication.CreateBuilder(args);
ConfigurationManager configuration = builder.Configuration;
// Add services to the container.
builder.Services.AddDbContext<DataBaseContext>(options =>
             options.UseSqlServer(builder.Configuration.GetConnectionString("sqlConnction"))
               );

// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddCors(o => {
    o.AddPolicy("CoursPolict", bulder => bulder.AllowAnyOrigin().AllowAnyMethod().AllowAnyHeader());
});






builder.Services.AddControllers();
builder.Services.AddAutoMapper(typeof(MapperInitilizer));
builder.Services.AddTransient<IUnitOfWork, UnitOfWork>();
//builder.Services.AddScoped<IAuthManger, AuthManger>();

builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

//makram
builder.Services.AddIdentity<IdentityUser, IdentityRole>()
              .AddEntityFrameworkStores<DataBaseContext>()
              .AddDefaultTokenProviders();

builder.Services.AddControllers().AddNewtonsoftJson(op =>
op.SerializerSettings.ReferenceLoopHandling = Newtonsoft.Json.ReferenceLoopHandling.Ignore

);

builder.Services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme).AddJwtBearer(
    options =>
    {
        options.TokenValidationParameters = new TokenValidationParameters
        {
            ValidateIssuer = false,
            ValidateAudience = false,
            ValidateLifetime = true,
            ValidateIssuerSigningKey = true,
            IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(builder.Configuration["JWTKEY"])),
            ClockSkew = TimeSpan.Zero

        };
    }


    );











var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}
app.UseSwagger();
app.UseSwaggerUI(c =>
{
    string swagerpath = string.IsNullOrWhiteSpace(c.RoutePrefix) ? "." : "..";
    c.SwaggerEndpoint($"{swagerpath}/swagger/v1/Swagger.jason", "Hotel listing Api");

});



app.UseSwagger();
app.UseSwaggerUI();
app.UseAuthorization();
app.UseCors("CoursPolict");
app.MapControllers();

app.Run();
