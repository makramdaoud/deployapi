﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using PharmApi.Data;
using PharmApi.IRepository;

namespace PharmApi.Repository
{
    public class UnitOfWork : IUnitOfWork
    {
        private readonly DataBaseContext _context;
        
        private IGenericRepository<meetupdata> _meetupdata;
        private IGenericRepository<accountshortcutstor> _accountshortcutstors;
        private IGenericRepository<ACCLeadger> _ACCLeadger;
        private IGenericRepository<ACCOUNTINSH> _ACCOUNTINSH;
        private IGenericRepository<Cheque> _Cheque;
        private IGenericRepository<Company> _Company;
        private IGenericRepository<Coupon> _Coupon;
        private IGenericRepository<Currency> _Currency;
        private IGenericRepository<Customer> _Customer;
        private IGenericRepository<Customer_branches> _Customer_branches;
        private IGenericRepository<Customer_Contracts> _Customer_Contracts;
        private IGenericRepository<customer_credit_chng> _customer_credit_chng;
        private IGenericRepository<Customer_Delivery> _Customer_Delivery;
        private IGenericRepository<Customer_Groups> _Customer_Groups;
        private IGenericRepository<Customer_Items> _Customer_Items;
        private IGenericRepository<Customer_Points_Calc> _Customer_Points_Calc;
        private IGenericRepository<Customer_Rules> _Customer_Rules;
        private IGenericRepository<Customer_Type> _Customer_Type;
        private IGenericRepository<Customer_Visa> _Customer_Visa;
        private IGenericRepository<deleveryinformation> _deleveryinformation;
        private IGenericRepository<Deposit> _Deposit;
        private IGenericRepository<Deposit_Bank> _Deposit_Bank;
        private IGenericRepository<Education> _Education;
        private IGenericRepository<Employ> _Employ;
        private IGenericRepository<Employ_ledger> _Employ_ledger;
        private IGenericRepository<employhistory> _employhistory;
        private IGenericRepository<Group> _Group;
        private IGenericRepository<inersales_trans_d> _inersales_trans_d;
        private IGenericRepository<inersales_trans_h> _inersales_trans_h;

        private IGenericRepository<info> _info;
        private IGenericRepository<InterCode> _InterCode;
        private IGenericRepository<inventory_d> _inventory_d;
        private IGenericRepository<inventory_h> _inventory_h;
        private IGenericRepository<Item_Catalog> _Item_Catalog;
        private IGenericRepository<Item_Chlied> _Item_Chlied;
        private IGenericRepository<Item_Objects> _Item_Objects;
        private IGenericRepository<Item_Origins> _Item_Origins;
        private IGenericRepository<item_usage_manner> _item_usage_manner;
        private IGenericRepository<ITEMSELECTED> _ITEMSELECTED;
        private IGenericRepository<kit> _kit;
        private IGenericRepository<kpitable> _kpitable;
        private IGenericRepository<PaymentVoucher> _PaymentVoucher;
        private IGenericRepository<Payable> _Payable;
        private IGenericRepository<LoanDetails> _LoanDetails;
        private IGenericRepository<GeneralLedger> _GeneralLedger;
        private IGenericRepository<FSDetails> _FSDetails;
        private IGenericRepository<FinancialStatements> _FinancialStatements;


        private IGenericRepository<pur_trans_d> _pur_trans_d;
        private IGenericRepository<pur_trans_h> _pur_trans_h;
        private IGenericRepository<return_trans_d> _return_trans_d;
        private IGenericRepository<return_trans_h> _return_trans_h;
        private IGenericRepository<sales_trans_d> _sales_trans_d;
        private IGenericRepository<sales_trans_h> _sales_trans_h;
        private IGenericRepository<stock> _stock;
        private IGenericRepository<PHARM_TRAN_H> _PHARM_TRAN_H;
        private IGenericRepository<PHARM_TRAN_D> _PHARM_TRAN_D;
        private IGenericRepository<Pharm_Recive_H_PH> _Pharm_Recive_H_PH;
        private IGenericRepository<Pharm_Recive_D_PH> _Pharm_Recive_D_PH;
        private IGenericRepository<AccountsChart> _AccountsChart;
        
        public UnitOfWork(DataBaseContext context)
        {
            _context = context;

        }
        

        public IGenericRepository<meetupdata> meetupdata => _meetupdata ??= new GenericRepository<meetupdata>(_context);

        public IGenericRepository<AccountsChart> AccountsChart => _AccountsChart ??= new GenericRepository<AccountsChart>(_context);
        public IGenericRepository<pur_trans_d> pur_trans_d => _pur_trans_d ??= new GenericRepository<pur_trans_d>(_context);
        public IGenericRepository<pur_trans_h> pur_trans_h => _pur_trans_h ??= new GenericRepository<pur_trans_h>(_context);
        public IGenericRepository<return_trans_d> return_trans_d => _return_trans_d ??= new GenericRepository<return_trans_d>(_context);
        public IGenericRepository<return_trans_h> return_trans_h => _return_trans_h ??= new GenericRepository<return_trans_h>(_context);
        public IGenericRepository<sales_trans_d> sales_trans_d => _sales_trans_d ??= new GenericRepository<sales_trans_d>(_context);
        public IGenericRepository<sales_trans_h> sales_trans_h => _sales_trans_h ??= new GenericRepository<sales_trans_h>(_context);
        public IGenericRepository<stock> accountshortcutstor => _stock ??= new GenericRepository<stock>(_context);
        public IGenericRepository<PHARM_TRAN_H> PHARM_TRAN_H => _PHARM_TRAN_H ??= new GenericRepository<PHARM_TRAN_H>(_context);
        public IGenericRepository<PHARM_TRAN_D> PHARM_TRAN_D => _PHARM_TRAN_D ??= new GenericRepository<PHARM_TRAN_D>(_context);
        public IGenericRepository<Pharm_Recive_H_PH> Pharm_Recive_H_PH => _Pharm_Recive_H_PH ??= new GenericRepository<Pharm_Recive_H_PH>(_context);
        public IGenericRepository<Pharm_Recive_D_PH> Pharm_Recive_D_PH => _Pharm_Recive_D_PH ??= new GenericRepository<Pharm_Recive_D_PH>(_context);





        //makram
        public IGenericRepository<accountshortcutstor> accountshortcutstors => _accountshortcutstors ??= new GenericRepository<accountshortcutstor>(_context);

        public IGenericRepository<ACCLeadger> ACCLeadgerS => _ACCLeadger ??= new GenericRepository<ACCLeadger>(_context);

        public IGenericRepository<ACCOUNTINSH> ACCOUNTINSHS => _ACCOUNTINSH ??= new GenericRepository<ACCOUNTINSH>(_context);

        public IGenericRepository<Cheque> Cheque => _Cheque ??= new GenericRepository<Cheque>(_context);

        public IGenericRepository<Company> Company => _Company ??= new GenericRepository<Company>(_context);

        public IGenericRepository<Coupon> Coupon => _Coupon ??= new GenericRepository<Coupon>(_context);

        public IGenericRepository<Currency> Currency => _Currency ??= new GenericRepository<Currency>(_context);

        public IGenericRepository<Customer> Customer => _Customer ??= new GenericRepository<Customer>(_context);

        public IGenericRepository<Customer_branches> Customer_branches => _Customer_branches ??= new GenericRepository<Customer_branches>(_context);

        public IGenericRepository<Customer_Contracts> Customer_Contracts => _Customer_Contracts ??= new GenericRepository<Customer_Contracts>(_context);

        public IGenericRepository<customer_credit_chng> customer_credit_chng => _customer_credit_chng ??= new GenericRepository<customer_credit_chng>(_context);

        public IGenericRepository<Customer_Delivery> Customer_Delivery => _Customer_Delivery ??= new GenericRepository<Customer_Delivery>(_context);

        public IGenericRepository<Customer_Groups> Customer_Groups => _Customer_Groups ??= new GenericRepository<Customer_Groups>(_context);

        public IGenericRepository<Customer_Items> Customer_Items => _Customer_Items ??= new GenericRepository<Customer_Items>(_context);

        public IGenericRepository<Customer_Points_Calc> Customer_Points_Calc => _Customer_Points_Calc ??= new GenericRepository<Customer_Points_Calc>(_context);

        public IGenericRepository<Customer_Rules> Customer_Rules => _Customer_Rules ??= new GenericRepository<Customer_Rules>(_context);

        public IGenericRepository<Customer_Type> Customer_Type => _Customer_Type ??= new GenericRepository<Customer_Type>(_context);

        public IGenericRepository<Customer_Visa> Customer_Visa => _Customer_Visa ??= new GenericRepository<Customer_Visa>(_context);

        public IGenericRepository<deleveryinformation> deleveryinformation => _deleveryinformation ??= new GenericRepository<deleveryinformation>(_context);

        public IGenericRepository<Deposit> Deposit => _Deposit ??= new GenericRepository<Deposit>(_context);

        public IGenericRepository<Deposit_Bank> Deposit_Bank => _Deposit_Bank ??= new GenericRepository<Deposit_Bank>(_context);

        public IGenericRepository<Education> Education => _Education ??= new GenericRepository<Education>(_context);

        public IGenericRepository<Employ> Employ => _Employ ??= new GenericRepository<Employ>(_context);

        public IGenericRepository<Employ_ledger> Employ_ledger => _Employ_ledger ??= new GenericRepository<Employ_ledger>(_context);

        public IGenericRepository<employhistory> employhistory => _employhistory ??= new GenericRepository<employhistory>(_context);

        public IGenericRepository<Group> Group => _Group ??= new GenericRepository<Group>(_context);

        public IGenericRepository<inersales_trans_d> inersales_trans_d => _inersales_trans_d ??= new GenericRepository<inersales_trans_d>(_context);

        public IGenericRepository<inersales_trans_h> inersales_trans_h => _inersales_trans_h ??= new GenericRepository<inersales_trans_h>(_context);

        public IGenericRepository<info> info => _info ??= new GenericRepository<info>(_context);

        public IGenericRepository<InterCode> InterCode => _InterCode ??= new GenericRepository<InterCode>(_context);

        public IGenericRepository<inventory_d> inventory_d => _inventory_d ??= new GenericRepository<inventory_d>(_context);

        public IGenericRepository<inventory_h> inventory_h => _inventory_h ??= new GenericRepository<inventory_h>(_context);

        public IGenericRepository<Item_Catalog> Item_Catalog => _Item_Catalog ??= new GenericRepository<Item_Catalog>(_context);

        public IGenericRepository<Item_Chlied> Item_Chlied => _Item_Chlied ??= new GenericRepository<Item_Chlied>(_context);

        public IGenericRepository<Item_Objects> Item_Objects => _Item_Objects ??= new GenericRepository<Item_Objects>(_context);

        public IGenericRepository<Item_Origins> Item_Origins => _Item_Origins ??= new GenericRepository<Item_Origins>(_context);

        public IGenericRepository<item_usage_manner> item_usage_manner => _item_usage_manner ??= new GenericRepository<item_usage_manner>(_context);

        public IGenericRepository<ITEMSELECTED> ITEMSELECTED => _ITEMSELECTED ??= new GenericRepository<ITEMSELECTED>(_context);

        public IGenericRepository<kit> kit => _kit ??= new GenericRepository<kit>(_context);

        public IGenericRepository<kpitable> kpitable => _kpitable ??= new GenericRepository<kpitable>(_context);

        public IGenericRepository<PaymentVoucher> PaymentVoucher => _PaymentVoucher ??= new GenericRepository<PaymentVoucher>(_context);

        public IGenericRepository<Payable> Payable => _Payable ??= new GenericRepository<Payable>(_context);

        public IGenericRepository<LoanDetails> LoanDetails => _LoanDetails ??= new GenericRepository<LoanDetails>(_context);

        public IGenericRepository<GeneralLedger> GeneralLedger => _GeneralLedger ??= new GenericRepository<GeneralLedger>(_context);

        public IGenericRepository<FSDetails> FSDetails => _FSDetails ??= new GenericRepository<FSDetails>(_context);

        public IGenericRepository<FinancialStatements> FinancialStatements => _FinancialStatements ??= new GenericRepository<FinancialStatements>(_context);

        public void Dispose()
        {
            _context.Dispose();
            GC.SuppressFinalize(this);
        }

        public async Task Save()
        {
            await _context.SaveChangesAsync();
        }
    }
}
