﻿using AutoMapper;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using PharmApi.Data;
using PharmApi.IRepository;
using PharmApi.Model;

namespace PharmApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class meetupdataController : ControllerBase
    {
        private readonly IUnitOfWork unitOfWork;
        private readonly ILogger<accountshortcutstorController> logger;
        private readonly IMapper mapper;


        public meetupdataController(IUnitOfWork UnitOfWork, ILogger<accountshortcutstorController> Logger, IMapper mapper)
        {

            unitOfWork = UnitOfWork;
            logger = Logger;
            this.mapper = mapper;
        }

        [HttpPost]
        public async Task<IActionResult> insertmeetupdata([FromBody] CreatemeetupdataDTO meetupdataDTO)
        {
            if (!ModelState.IsValid)
            {
                logger.LogError($"some thing went rong {nameof(insertmeetupdata)}");
                return StatusCode(500, "ome thing wrong ");
            }


            var ob = mapper.Map<meetupdata>(meetupdataDTO);
            await unitOfWork.meetupdata.Insert(ob);
            await unitOfWork.Save();
            return Ok(ob);

        }

        [HttpGet]
        public async Task<IActionResult> GETALLACCOUNTCAR()
        {
            try
            {
                var chart = await unitOfWork.meetupdata.GetAll();
                var result = mapper.Map<IList<meetupdataDTO>>(chart);
                return Ok(result);

            }
            catch (System.Exception EX)
            {

                logger.LogError(EX, $"some thing went rong {nameof(GETALLACCOUNTCAR)}");
                return StatusCode(500, "ome thing wrong ");
            }
        }






    }
}
