﻿using AutoMapper;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using PharmApi.Data;
using PharmApi.IRepository;
using PharmApi.Model;

namespace PharmApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class accountshortcutstorController : ControllerBase
    {
        private readonly IUnitOfWork unitOfWork;
        private readonly ILogger<accountshortcutstorController> logger;
        private readonly IMapper mapper;

        public accountshortcutstorController(IUnitOfWork UnitOfWork, ILogger<accountshortcutstorController> Logger, IMapper mapper)
        {

            unitOfWork = UnitOfWork;
            logger = Logger;
            this.mapper = mapper;
        }


        [HttpPost]
        public async Task<IActionResult> insertaccountchart([FromBody] CreateaccountshortcutstorDTO accountshortcutstorDTO)
        {
            if (!ModelState.IsValid)
            {
                logger.LogError($"some thing went rong {nameof(insertaccountchart)}");
                return StatusCode(500, "ome thing wrong ");
            }


            var ob = mapper.Map<accountshortcutstor>(accountshortcutstorDTO);
            await unitOfWork.accountshortcutstors.Insert(ob);
            await unitOfWork.Save();
            return Ok(ob);

        }



        [HttpGet]
        public async Task<IActionResult> GETALLACCOUNTCAR()
        {
            try
            {
                var chart = await unitOfWork.accountshortcutstors.GetAll();
                var result = mapper.Map<IList<accountshortcutstorDTO>>(chart);
                return Ok(result);

            }
            catch (System.Exception EX)
            {

                logger.LogError(EX, $"some thing went rong {nameof(GETALLACCOUNTCAR)}");
                return StatusCode(500, "ome thing wrong ");
            }
        }




        [HttpGet("{id}")]
        public async Task<IActionResult> stockcode(int id)
        {
            try
            {

                var chart = await unitOfWork.accountshortcutstors.GetAll(s => s.id == id);
                var result = mapper.Map<IList<accountshortcutstorDTO>>(chart);
                return Ok(result);

            }
            catch (System.Exception EX)
            {

                logger.LogError(EX, $"some thing went rong {nameof(GETALLACCOUNTcode)}");
                return StatusCode(500, "ome thing wrong ");
            }
        }

        [HttpGet("{idd}")]
        public async Task<IActionResult> GETALLACCOUNTcode(string idd)
        {
            try
            {

                var chart = await unitOfWork.accountshortcutstors.GetAll(s => s.pharm_code  == idd ||s.pharmname == idd || s.StoreId == idd);
                var result = mapper.Map<IList<AccountsChartDTO>>(chart);
                return Ok(result);

            }
            catch (System.Exception EX)
            {

                logger.LogError(EX, $"some thing went rong {nameof(GETALLACCOUNTcode)}");
                return StatusCode(500, "ome thing wrong ");
            }
        }

    }


}
