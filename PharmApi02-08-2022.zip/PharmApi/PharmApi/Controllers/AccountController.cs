﻿using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.IdentityModel.Tokens;
using PharmApi.Data;
using PharmApi.Model;
using System.Security.Claims;
using System.Text;
using PharmApi.Configrations;
using System.IdentityModel.Tokens.Jwt;

namespace PharmApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AccountController: ControllerBase
    {
        private readonly UserManager<IdentityUser> userManager;
        private readonly SignInManager<IdentityUser> signInManager;
        private readonly IConfiguration configuration;

        public AccountController(UserManager<IdentityUser> UserManager,SignInManager<IdentityUser> SignInManager ,IConfiguration Configuration)
        {
            userManager = UserManager;
            signInManager = SignInManager;
            configuration = Configuration;


        }
        [HttpPost("create")]
        public async Task<ActionResult<Authentication>> create([FromBody] UserCredintial UserCredintial)
        {
            var user = new APIUser { UserName = UserCredintial.Email, Email = UserCredintial.Email };
            var result = await userManager.CreateAsync(user,UserCredintial.Password );
            if (result.Succeeded)
            {
                return buildtoken(UserCredintial);
            }
            else
            {
                return BadRequest(result.Errors);
            }


            

        }


        [HttpPost("login")]
        public async Task<ActionResult<Authentication>> login([FromBody] UserCredintial UserCredintial)
        {
            var result = await signInManager.PasswordSignInAsync(UserCredintial.Email, UserCredintial.Password, isPersistent: false, lockoutOnFailure: false);

            if (result.Succeeded)
            {
                return buildtoken(UserCredintial);
            }
            else
            {
                return BadRequest("incorect log in ");
            }
        }




        private Authentication buildtoken(UserCredintial UserCredintial)
        {
            var clims = new List<Claim>()
            {
                new Claim("emai",UserCredintial.Email)
            };
            var Key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(configuration["JWTKEY"]));
            var cred = new SigningCredentials(Key, SecurityAlgorithms.HmacSha256);
            var expiration = DateTime.UtcNow.AddDays(1);
            var token = new JwtSecurityToken(issuer: null, audience: null, claims: clims, expires: expiration, signingCredentials: cred);

            return new Authentication()
            {
                Token = new JwtSecurityTokenHandler().WriteToken(token),
                Expiration = expiration
            };
        }

    }
}
