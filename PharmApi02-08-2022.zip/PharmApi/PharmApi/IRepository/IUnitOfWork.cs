﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using PharmApi.Data;

namespace PharmApi.IRepository
{
    public interface IUnitOfWork : IDisposable
    {
        IGenericRepository<accountshortcutstor> accountshortcutstors { get; }
        IGenericRepository<meetupdata> meetupdata { get; }
        
         IGenericRepository<AccountsChart> AccountsChart { get; }
        IGenericRepository<ACCLeadger> ACCLeadgerS { get; }
        IGenericRepository<ACCOUNTINSH> ACCOUNTINSHS { get; }
        IGenericRepository<Cheque> Cheque { get; }
        IGenericRepository<Company> Company { get; }
        IGenericRepository<Coupon> Coupon { get; }
        IGenericRepository<Currency> Currency { get; }
        IGenericRepository<Customer> Customer { get; }
        IGenericRepository<Customer_branches> Customer_branches { get; }
        IGenericRepository<Customer_Contracts> Customer_Contracts { get; }
        IGenericRepository<customer_credit_chng> customer_credit_chng { get; }
        IGenericRepository<Customer_Delivery> Customer_Delivery { get; }
        IGenericRepository<Customer_Groups> Customer_Groups { get; }
        IGenericRepository<Customer_Items> Customer_Items { get; }
        IGenericRepository<Customer_Points_Calc> Customer_Points_Calc { get; }
        IGenericRepository<Customer_Rules> Customer_Rules { get; }
        IGenericRepository<Customer_Type> Customer_Type { get; }
        IGenericRepository<Customer_Visa> Customer_Visa { get; }
        IGenericRepository<deleveryinformation> deleveryinformation { get; }
        IGenericRepository<Deposit> Deposit { get; }
        IGenericRepository<Deposit_Bank> Deposit_Bank { get; }
        IGenericRepository<Education> Education { get; }
        IGenericRepository<Employ> Employ { get; }
        IGenericRepository<Employ_ledger> Employ_ledger { get; }
        IGenericRepository<employhistory> employhistory { get; }
        IGenericRepository<Group> Group { get; }
        IGenericRepository<inersales_trans_d> inersales_trans_d { get; }
        IGenericRepository<inersales_trans_h> inersales_trans_h { get; }
        IGenericRepository<info> info { get; }
        IGenericRepository<InterCode> InterCode { get; }
        IGenericRepository<inventory_d> inventory_d { get; }
        IGenericRepository<inventory_h> inventory_h { get; }
        IGenericRepository<Item_Catalog> Item_Catalog { get; }
        IGenericRepository<Item_Chlied> Item_Chlied { get; }
        IGenericRepository<Item_Objects> Item_Objects { get; }
        IGenericRepository<Item_Origins> Item_Origins { get; }
        IGenericRepository<item_usage_manner> item_usage_manner { get; }

        IGenericRepository<ITEMSELECTED> ITEMSELECTED { get; }
        IGenericRepository<kit> kit { get; }
        IGenericRepository<kpitable> kpitable { get; }
        IGenericRepository<PaymentVoucher> PaymentVoucher { get; }
        IGenericRepository<Payable> Payable { get; }
        IGenericRepository<LoanDetails> LoanDetails { get; }
        IGenericRepository<GeneralLedger> GeneralLedger { get; }
        IGenericRepository<FSDetails> FSDetails { get; }
        IGenericRepository<FinancialStatements> FinancialStatements { get; }

        IGenericRepository<pur_trans_d> pur_trans_d { get; }
        IGenericRepository<pur_trans_h> pur_trans_h { get; }
        IGenericRepository<return_trans_d> return_trans_d { get; }
        IGenericRepository<return_trans_h> return_trans_h { get; }
        IGenericRepository<sales_trans_d> sales_trans_d { get; }
        IGenericRepository<sales_trans_h> sales_trans_h { get; }
        IGenericRepository<stock> accountshortcutstor { get; }
        IGenericRepository<PHARM_TRAN_H> PHARM_TRAN_H { get; }
        IGenericRepository<PHARM_TRAN_D> PHARM_TRAN_D { get; }
        IGenericRepository<Pharm_Recive_H_PH> Pharm_Recive_H_PH { get; }
        IGenericRepository<Pharm_Recive_D_PH> Pharm_Recive_D_PH { get; }


        Task Save();

    }
}
