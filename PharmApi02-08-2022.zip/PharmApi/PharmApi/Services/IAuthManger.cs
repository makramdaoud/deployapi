﻿using System.Threading.Tasks;
using PharmApi.Model;

namespace PharmApi.Services
{
    public interface IAuthManger
    {
        Task<bool> ValidateUser(LOgUserDTO UserDTO);
        Task<string> CreateToken();
    }
}
