﻿using AutoMapper.Configuration;
using Microsoft.AspNetCore.Identity;
using Microsoft.IdentityModel.Tokens;
using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;
using PharmApi.Data;
using PharmApi.Model;

namespace PharmApi.Services
{
    public class AuthManger : IAuthManger
    {
        private readonly UserManager<APIUser> _usermanger;
        private readonly AutoMapper.Configuration.IConfiguration _configuration;
        private  APIUser _uer;

        public AuthManger(UserManager<APIUser> usermanger, AutoMapper.Configuration.IConfiguration configuration)
        {
            _usermanger = usermanger;
            _configuration = configuration;
        }

        public async Task<string> CreateToken()
        {
            var SigningCreditional = GetSigningCreditional();
            var Claims = await  Getclaims();
            var token = GeneratTokenOptions(SigningCreditional, Claims);

            return  new JwtSecurityTokenHandler().WriteToken(token);

        }

        private JwtSecurityToken GeneratTokenOptions(SigningCredentials signingCreditional, List<Claim> Claims)
        {
           
            //var jwtSetting = configuration.GetSection("Jwt");
            var expiretion = DateTime.Now.AddMinutes(Convert.ToDouble(15));
            var token = new JwtSecurityToken
                (
                issuer: "PharmApi",
                claims: Claims,
                expires: expiretion ,
                signingCredentials: signingCreditional
                );
            return token;

        }

        private async Task<List<Claim>> Getclaims()
        {
            var calims = new List<Claim>
              {
                  new Claim(ClaimTypes.Name,_uer.UserName)


               };
         


            var roles =await _usermanger.GetRolesAsync(_uer);
            foreach (var role in roles)
            {

                calims.Add(new Claim(ClaimTypes.Role, role));    
            }

            return calims;

        }

        private SigningCredentials GetSigningCreditional()
        {
            var key = Environment.GetEnvironmentVariable("KEY");
            var SECRET = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(key));
            return new SigningCredentials(SECRET, SecurityAlgorithms.HmacSha256);
        }

        public async  Task<bool> ValidateUser(LOgUserDTO UserDTO)
        {
            _uer = await _usermanger.FindByNameAsync(UserDTO.Email);
            return (_uer != null && await _usermanger.CheckPasswordAsync(_uer, UserDTO.Password));    

        }
    }
}
